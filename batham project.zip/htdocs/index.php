<!DOCTYPE html>
<!-- saved from url=(0025)https://indore.nic.in/en/ -->
<html lang="en-US" class="js_active  vc_desktop  vc_transform  vc_transform"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>
  District Indore,Goverment Of Madhya Pradesh | Commercial Capital of M.P. | India  </title>
            <link rel="icon" href="./projectibm_files/2019062152.jpg">
      <style>
    @font-face {
      font-family: 'icomoon';
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq");
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq#iefix") format("embedded-opentype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.ttf?y6palq") format("truetype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.woff?y6palq") format("woff"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.svg?y6palq#icomoon") format("svg");
      font-weight: normal;
      font-style: normal; }
  </style>
  <link rel="profile" href="http://gmpg.org/xfn/11">
  <link rel="pingback" href="https://indore.nic.in/xmlrpc.php">
    <link rel="dns-prefetch" href="https://s.w.org/">
<meta name="description" content="Commercial Capital of M.P.">
<meta name="keywords" content="Home">
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/indore.nic.in\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./projectibm_files/wp-emoji-release.min.js.download" defer=""></script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="theme-my-login-css" href="./projectibm_files/theme-my-login.css" media="all">
<link rel="stylesheet" id="wp-block-library-css" href="./projectibm_files/style.min.css" media="all">
<link rel="stylesheet" id="base-css-css" href="./projectibm_files/base.css" media="all">
<link rel="stylesheet" id="extra-feature-css-css" href="./projectibm_files/extra.features.css" media="all">
<link rel="stylesheet" id="contact-form-7-css" href="./projectibm_files/styles.css" media="all">
<link rel="stylesheet" id="wsl-widget-css" href="./projectibm_files/style.css" media="all">
<link rel="stylesheet" id="sliderhelper-css-css" href="./projectibm_files/sliderhelper.css" media="all">
<link rel="stylesheet" id="main-css-css" href="./projectibm_files/style(1).css" media="all">
<link rel="stylesheet" id="js_composer_front-css" href="./projectibm_files/js_composer.min.css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="./projectibm_files/font-awsome.css" media="all">
<link rel="stylesheet" id="extra_css-css" href="./projectibm_files/extra.css" media="screen">
<script src="./projectibm_files/jquery.js.download"></script>
<script src="./projectibm_files/jquery-migrate.min.js.download"></script>
<script src="./projectibm_files/themed-profiles.js.download"></script>
<script src="./projectibm_files/external.js.download"></script>
<link rel="https://api.w.org/" href="https://indore.nic.in/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://indore.nic.in/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://indore.nic.in/wp-includes/wlwmanifest.xml"> 
<link rel="canonical" href="https://indore.nic.in/en/">
<link rel="shortlink" href="https://indore.nic.in/">
<link rel="alternate" type="application/json+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2F">
<link rel="alternate" type="text/xml+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2F&amp;format=xml">
    <noscript>
        <style>
			
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ visibility: visible;}
            #topBar #accessibility ul li .socialIcons ul, #topBar1 #accessibility ul li .socialIcons ul { background: #fff !important;}
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ right: 0; left: inherit;}
            .nav li a:focus > ul { left: 0; opacity: 0.99;}
            a:focus, button:focus, .carasoleflex-wrap .flexslider .slides > li a:focus, .flexslider .slides>li a:focus
            { outline: 3px solid #ff8c00 !important;}
            .flexslider .slides>li { display:block;}
            .nav li.active > a, .nav li > a:hover, .nav li > a:focus, .nav ul li a:hover,
            .mva7-thc-activetheme-district-theme-13 .nav li:hover > a, .mva7-thc-activetheme-district-theme-13 .nav li.active > a, .home-13 .nav li:hover > a, .home-13 .nav li.active > a{color:#ffffff;}
            .nav li:hover > a{ border-top:none; color:#ffffff;}
            .nav li.active > a{ border:0;}
            .nav ul{ opacity:1; left:0; position:static !important; width:auto; border:0;}
            .nav li{ position:static !important; display:block; float:none; border:0 !important;}
            .nav li>a { float:none; display:block; background-color:rgba(146,38,4,0.75) !important; color:#ffffff; margin:0; padding:12px 20px !important; border-radius:0; border-bottom:1px solid #ffffff !important; position:static !important; border-top:0; font-size:14px !important;}
            .nav ul.sub-menu li >a{ background-color:rgba(146,38,4,1); font-size:12px !important;}
            ul li .socialIcons{ visibility:visible !important;}
            .mva7-thc-activetheme-district-theme .nav li > a,
            .mva7-thc-activetheme-district-theme .nav li.active > a{ background-color:#9e6b22 !important;}
            .mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a{ background-color:#f3b45b !important;}

            .mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .mva7-thc-activetheme-district-theme-15 .menuWrapper{ background-color:#ffffff;}

            .mva7-thc-activetheme-district-theme-2 .nav li > a,
            .mva7-thc-activetheme-district-theme-2 .nav li.active > a{ background-color:rgba(63,77,184,0.75) !important;}
            .mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a{ background-color:rgba(63,77,184,1) !important;}

            .mva7-thc-activetheme-district-theme-3 .nav li > a,
            .mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .mva7-thc-activetheme-district-theme-5 .nav li > a,
            .mva7-thc-activetheme-district-theme-5 .nav li.active > a{ background-color:rgba(212,60,60,0.75) !important;}
            .mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a{ background-color:rgba(212,60,60,1) !important;}

            .mva7-thc-activetheme-district-theme-4 .nav li > a,
            .mva7-thc-activetheme-district-theme-4 .nav li.active > a{ background-color:rgba(184,48,88,0.75) !important;}
            .mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a{ background-color:rgba(184,48,88,1) !important;}

            .mva7-thc-activetheme-district-theme-6 .nav li > a,
            .mva7-thc-activetheme-district-theme-6 .nav li.active > a{ background-color:rgba(16,91,122,0.75) !important;}
            .mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a{ background-color:rgba(16,91,122,1) !important;}

            .mva7-thc-activetheme-district-theme-7 .nav li > a,
            .mva7-thc-activetheme-district-theme-7 .nav li.active > a{ background-color:rgba(2,20,80,0.75) !important;}
            .mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a{ background-color:rgba(2,20,80,1) !important;}

            .mva7-thc-activetheme-district-theme-8 .nav li > a,
            .mva7-thc-activetheme-district-theme-8 .nav li.active > a{ background-color:rgba(0,144,145,0.65) !important;}
            .mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a{ background-color:rgba(0,144,145,1) !important;}

            .mva7-thc-activetheme-district-theme-9 .nav li > a,
            .mva7-thc-activetheme-district-theme-9 .nav li.active > a{ background-color:rgba(60,125,20,0.75) !important;}
            .mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a{ background-color:rgba(60,125,20,1) !important;}

            .mva7-thc-activetheme-district-theme-10 .nav li > a,
            .mva7-thc-activetheme-district-theme-10 .nav li.active > a{ background-color:rgba(233,13,65,0.70) !important;}
            .mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a{ background-color:rgba(233,13,65,1) !important;}

            .mva7-thc-activetheme-district-theme-11 .nav li > a,
            .mva7-thc-activetheme-district-theme-11 .nav li.active > a{ background-color:rgba(104,57,127,0.75) !important;}
            .mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a{ background-color:rgba(104,57,127,1) !important;}

            .mva7-thc-activetheme-district-theme-13 .nav li > a,
            .mva7-thc-activetheme-district-theme-13 .nav li.active > a{ background-color:rgba(0,0,0,0.75) !important;}
            .mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a{ background-color:rgba(0,0,0,1) !important;}

            .mva7-thc-activetheme-district-theme-14 .nav li > a,
            .mva7-thc-activetheme-district-theme-14 .nav li.active > a{ background-color:rgba(0,120,175,0.75) !important;}
            .mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a{ background-color:rgba(0,120,175,1) !important;}

            .mva7-thc-activetheme-district-theme-15 .nav li > a,
            .mva7-thc-activetheme-district-theme-15 .nav li.active > a{ background-color:rgba(150,86,104,0.75) !important;}
            .mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a{ background-color:rgba(150,86,104,1) !important;}y

            /*for high contrast css*/
            .contrast #topBar #accessibility ul li .socialIcons ul, .contrast #topBar1 #accessibility ul li .socialIcons ul,
            .contrast .nav li>a, .contrast .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-15 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a,
            body.contrast
            { background-color:#000 !important;}
            .contrast a, .contrast .socialIcons.select-lang a{ color:#ffff00 !important;}
            body.contrast, .contrast p, .contrast div, .contrast table{ color: #fff !important}
        </style>
    </noscript>
    <link rel="alternate" href="https://indore.nic.in/en/" hreflang="x-default"><link rel="alternate" href="https://indore.nic.in/en/" hreflang="en">
<link rel="alternate" href="https://indore.nic.in/" hreflang="hi">
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://indore.nic.in/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-32x32.jpg" sizes="32x32">
<link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-192x192.jpg" sizes="192x192">
<link rel="apple-touch-icon-precomposed" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-180x180.jpg">
<meta name="msapplication-TileImage" content="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-270x270.jpg">
<style data-type="vc_shortcodes-custom-css">.vc_custom_1510030286033{margin-top: 30px !important;margin-bottom: 30px !important;}.vc_custom_1509966838810{padding-bottom: 25px !important;background-color: #f5f2f2 !important;}.vc_custom_1509962199792{background-color: #100e32 !important;}.vc_custom_1510030217493{margin-right: 10px !important;margin-left: 10px !important;background-color: #f5f2f2 !important;}.vc_custom_1510030204939{margin-right: 10px !important;margin-left: 10px !important;background-color: #f5f2f2 !important;}.vc_custom_1510030176807{margin-left: 10px !important;background-color: #f5f2f2 !important;}.vc_custom_1500617027978{padding-top: 0px !important;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/html5shiv.min.js"></script>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/respond.min.js"></script>
<![endif]-->
<script>
  var ajaxurl = "https://indore.nic.in/wp-admin/admin-ajax.php";
</script>
<style type="text/css">.fancybox-margin{margin-right:17px;}</style></head>

<body class="home page-template-default page page-id-2609 mva7-thc-activetheme-district-theme lang-en wpb-js-composer js-comp-ver-5.4.7 vc_responsive js" style="font-size: 14px;">
  <!--<header id="mainHeader">-->
    <header>
      <div id="topBar" class="wrapper">
        <div class="container">
          <div class="push-right" role="navigation" aria-label="Primary">
            <div id="accessibility">
            <ul id="accessibilityMenu">
              
                
                              
                <li>
                  <a href="javascript:void(0);" title="Accessibility Links" aria-label="Accessibility Links" class="mobile-show accessible-icon"><span class="off-css">Accessibility Links</span><span class="icon-accessibility" aria-hidden="true"></span></a>
                  <div class="accessiblelinks textSizing">
                    <ul>
                      <li><a href="javascript:void(0);" aria-label="Font Size Increase" title="Font Size Increase"><span aria-hidden="true">A+</span><span class="off-css"> Font Size Increase</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Normal Font" title="Normal Font"><span aria-hidden="true">A</span><span class="off-css"> Normal Font</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Font Size Decrease" title="Font Size Decrease"><span aria-hidden="true">A-</span><span class="off-css"> Font Size Decrease</span></a></li>
                      <li class="highContrast dark tog-con">
                          <a href="javascript:void(0);" aria-label="High Contrast" title="High Contrast"><span aria-hidden="true">A</span> <span class="tcon">High Contrast</span></a>
                      </li>
                      <li class="highContrast light">
                          <a href="javascript:void(0);" aria-hidden="true" aria-label="Normal Contrast" title="Normal Contrast"><span aria-hidden="true">A</span> <span class="tcon">Normal Contrast</span></a>
                      </li>
                    </ul>
                  </div>
                </li>
                                
                              </ul>
            </div>
          </div>
          <div class="push-left">
            <div class="govBranding">
              
            </div>
          </div>
        </div>
      </div>
      <div class="wrapper header-wrapper">
        <div class="container header-container">
          <div class="logo">
            <a href="" aria-label="Go to home" class="emblem" rel="home">
                              <img class="site_logo" height="100" id="logo" src="./projectibm_files/2019062152.jpg" alt="MP Logo">
              
            <div class="logo-text">
                              <strong lang="hi" class="site_name_regional">जिला इंदौर </strong>
                                                              <h1 class="site_name_english">District Indore</h1>
                                          </div>
          </a>
        </div>
          
          <div class="header-right clearfix">
            <div class="right-content clearfix">
              <div class="float-element">
                                                
                      <img class="sw-logo" height="95" src="./projectibm_files/digital-india.png" alt="Digital India">
                    
                                </div>
            </div>
          </div>
          <a class="menuToggle" href="javascript:void(0);" aria-label="Mobile Menu"> <span class="icon-menu"></span><span class="tcon">Menu Toggle</span></a>
        </div>
      </div>



<div class="menuWrapper" style="max-height: 565px;">

  <div class="menuMoreText hide"></div>


  <div class="container">
    <nav class="menu"><ul id="menu-header-en" class="nav clearfix" role="menubar" aria-hidden="false"><li id="menu-item-2658" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-2658 active " role="menuitem"><a href="https://indore.nic.in/en" aria-current="page">Home</a></li>

</li>

<li id="menu-item-2833" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2833" role="menuitem"><a href="http://localhost/khushi/ibm%20registration%20popup.php">registration</a></li>
<li id="menu-item-2466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2466 has-sub" role="menuitem" aria-haspopup="true" aria-expanded="false"><a href="javascript:void(0)">citizen services<span class="indicator1"></span></a>
<ul class="sub-menu" role="menu">
	
	<li id="menu-item-26047" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-26047" role="menuitem"><a href="http://localhost/khushi/upload.php">caste certificate for SC/ST</a></li>
	<li id="menu-item-2493" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2493" role="menuitem"><a href="http://localhost/khushi/upload.php">caste certificate for OBC</a></li>
	
	
</ul>
</li>




</ul>

</header>

<div class="wrapper bodyWrapper no_padding" role="main">
    <div class="container home-1">
    
	    <div id="SkipContent" tabindex="-1"></div>
    <div class="row" id="row-content">
      <div class="col-12">
                  
            <div id="post-2609" class="post-2609 page type-page status-publish hentry">
		<div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding" style="position: relative; left: -117.4px; box-sizing: border-box; width: 1519px;"><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-offset-0"><div class="vc_column-inner "><div class="wpb_wrapper">        <div id="slide" class="home-slider full-cntrl-center-caption-bottom nav-white  flexslider ">
            
        <div class="flex-viewport" style="overflow: hidden; position: relative;"><ul class="slides" style="width: 2200%; transition-duration: 0s; transform: translate3d(-10633px, 0px, 0px);"><li class="clone" aria-hidden="true" style="width: 1519px; float: left; display: block;">
                                <img src="pro13.jpg" draggable="false">                                                                        <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"></p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li>
                                            <li style="width: 1519px; float: left; display: block;" class="">
                                <img src="pro12.jpg" draggable="false">                                                                        <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"> </p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li>
                                                        <li style="width: 1519px; float: left; display: block;" class="">
                                <img src="pro1.jpg" draggable="false">                                                                        <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"></p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li>
                                                        <li style="width: 1519px; float: left; display: block;" class="">
                                <img src="pro3.jpg"  draggable="false">                                                                        <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"></p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li>
                                                        <li style="width: 1519px; float: left; display: block;" class="">
                                <img src="pro4.jpg"  draggable="false">                                                                        <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"></p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li>
                                                        
                                                       
                                                                                                    
                                                                           
                                                       
                                                        
                                        <li style="width: 1519px; float: left; display: block;" class="clone" aria-hidden="true">
                                <img src="pro15.jpg" draggable="false">                                                                   <div class="container">
                                        <div class="slide-caption">
                                        <p class="heading3"></p>
                                            <p></p>

                                        </div>
                                    </div>
                                                                                                    </li></ul></div><ul class="flex-direction-nav"><li><a class="flex-prev" href="https://indore.nic.in/en/#" title="Previous" aria-label="Previous"><span class="hide">Previous</span></a></li><li><a class="flex-next" href="https://indore.nic.in/en/#" title="Next" aria-label="Next"><span class="hide">Next</span></a></li></ul><div class="flex-pauseplay"><a class="flex-pause" href="javascript:void(0)" title="Play/Pause" aria-label="Play/Pause"><span class="hide">Pause</span></a></div></div>
        <script>
       jQuery(document).ready(function($) {
            // Slider
            
            $('.home-slider').flexslider({
                animation: ($('body').hasClass('rtl'))?"fade":"slide",
                directionNav: true,
                prevText: "<span class='hide'>Previous</span>",
                nextText: "<span class='hide'>Next</span>",
                pausePlay: true,
                pauseText: "<span class='hide'>Pause</span>",
                playText: "<span class='hide'>Play</span>",
                controlNav: false,
                start: function(){
                    $('body').find('.flexslider').resize();
                }

            });
        });

    </script>
	<div class="wrapper" id="skipCont"></div>
    </div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1510030286033 vc_row-o-equal-height vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
		<div class="gen-list no-border no-bg padding-0 border-radius-medium iconTop-textBottom-box-list   normal-font ">
				<ul>
						<li class="blue-bg  border-radius-medium">
								<a  title="Indore Municipal Corporation, Indore" style="">
								<span class="list-icon blue-bg icon-accommodation border-radius-round"></span>
				
				<div class="list-text">1<br><span>Muncipal Corporation</span>
				</div>
								</a>
			 				</li>
								<li class="green-bg  border-radius-medium">
								<a  title="Tehsil" style="">
								<span class="list-icon green-bg icon-banks border-radius-round"></span>
				
				<div class="list-text">5<br><span>Tehsil</span>
				</div>
								</a>
			 				</li>
								<li class="red-bg  border-radius-medium">
								<a title="Subdivision &amp; Blocks" style="">
								<span class="list-icon orange-bg icon-accommodation border-radius-round"></span>
				
				<div class="list-text">4<br><span>Blocks</span>
				</div>
								</a>
			 				</li>
								<li class="orange-bg  border-radius-medium">
								<a  title="Police" style="">
								<span class="list-icon gray-bg icon-accommodation border-radius-round"></span>
				
				<div class="list-text">49<br><span> Police Station</span>
				</div>
								</a>
			 				</li>
						</ul>
				</div>
		</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510030217493"><div class="wpb_wrapper">    <div class="events-wrapper  with-bg ">
        <h2 class="heading3">EVENTS</h2>
                <div class="no-events"> There is no Event.</div>
                </div>
        </div></div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510030204939"><div class="wpb_wrapper">
		<div class="gen-list no-border no-bg padding-0 border-radius-none small-icon-list   normal-font ">
		<h2 class="heading3">INFORMATION</h2>		<ul>
						<li class="  ">
								<span class="list-icon gray-bg icon-identy border-radius-round"></span>
								<div class="list-text">Election Commission				</div>
								</a>
			 				</li>
								<li class="  ">
								<span class="list-icon orange-bg icon-identy border-radius-round"></span>
								<div class="list-text">Aadhaar Enrollment				</div>
								</a>
			 				</li>
								<li class="  ">
								<span class="list-icon green-bg icon-local-services border-radius-round"></span>
								<div class="list-text">NIC Service Desk				</div>
								</a>
			 				</li>
								<li class="  ">
								<span class="list-icon blue-bg icon-support border-radius-round"></span>
								<div class="list-text">Helpline				</div>
								</a>
			 				</li>
						</ul>
				</div>
		</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3 vc_col-has-fill"><div class="vc_column-inner vc_custom_1510030176807"><div class="wpb_wrapper"><div class="wpb_gmaps_widget wpb_content_element">
		<div class="wpb_wrapper">
		
			<iframe src="./projectibm_files/embed.html" height="300" style="border: 0px; pointer-events: none;" allowfullscreen="" title="District Map"></iframe>		</div>
	</div>
</div>
</div></div></div></div><div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid vc_custom_1509966838810 vc_row-has-fill" style="position: relative; left: -117.4px; box-sizing: border-box; width: 1519px; padding-left: 117.4px; padding-right: 117.6px;"><div class="wpb_column vc_column_container vc_col-sm-5"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div>
<h2>ABOUT DISTRICT</h2>
<p>Indore is situated on the Malwa plateau at an altitude of 553 m above sea level, on the banks of two small rivulets – the Saraswati and the Khan. They unite at the centre of the city where a small 18th century temple of Sangamnath or Indreshwar exists. The name Indore is due to this diety.</p>
<p></p></div>

		</div>
	</div>

		<div class="gen-list no-border no-bg padding-0 border-radius-none arrow-list  col-two normal-font ">
		<h2 class="heading3">AT A GLANCE</h2>		<ul>
						<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Area: </strong>10,863 Sq. Km.				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Population: </strong>34,06,061				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Language: </strong>Hindi				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Villages: </strong>676				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Male: </strong>16,60,412				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text"><strong>Female: </strong>18,60,400				</div>
							 </div>
			 				</li>
						</ul>
				</div>
		</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_tta-container" data-vc-action="collapse"><div class="vc_general vc_tta vc_tta-tabs vc_tta-color-grey vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group hor-hometab1 vc_tta-tabs-position-top vc_tta-controls-align-left hor-hometab1"><div class="vc_tta-tabs-container"><ul class="vc_tta-tabs-list" role="tablist"><li class="vc_tta-tab vc_active" data-vc-tab=""><a href="https://indore.nic.in/en/#whats-new-tab" data-vc-tabs="" data-vc-container=".vc_tta" role="tab" aria-controls="whats-new-tab" aria-selected="true"><span class="vc_tta-title-text">WHAT'S NEW</span></a></li><li class="vc_tta-tab" data-vc-tab=""></li><li class="vc_tta-tab" data-vc-tab=""></li><li class="vc_tta-tab" data-vc-tab=""></li><li class="vc_tta-tab" data-vc-tab=""></li></ul></div><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel vc_active" id="whats-new-tab" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#whats-new-tab" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">WHAT'S NEW</span></a></h4></div><div class="vc_tta-panel-body">    <div class="gen-list  no-border no-bg  padding-0 border-radius-medium default-list ">
                 <ul>
                            <li id="post-26119">
                            <a >Section 144 Order No. 1611 for prevention of Sound Pollution in Indore</a>
                                        </li>
                                                    <li id="post-26113">
                            <a >Order No 1625 u/s 144 : Prohibitory Order regarding Use of Vehicles in Public Transport</a>
                                        </li>
                                                    <li id="post-26100">
                            <a >District Indore : Additional Collectors Work Distribution Order</a>
                                        </li>
                                                    <li id="post-26096">
                            <a >Tender Notice for Hiring 4 Wheeler Diesel Vehicle with Driver in DUDA Indore</a>
                                        </li>
                                                    <li id="post-26082">
                            <a >Order No 83 u/s 144 : Regarding giving Information to Police Station within maximum 15 days timelimit for New Population getting added to Indore City everyday</a>
                                        </li>
                            
                            </ul>
            </div>
    </div></div><div class="vc_tta-panel" id="CIR-tab" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#CIR-tab" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">NEWS</span></a></h4></div><div class="vc_tta-panel-body">        <div class="gen-list  no-border no-bg  padding-0 border-radius-medium default-list ">
                    <ul>
                            <li>
                                            <a href="https://indore.nic.in/en/press-release-for-15-%e0%a4%85%e0%a4%97%e0%a4%b8%e0%a5%8d%e0%a4%a4-2019-independence-day-celebrations/">Press Release for 15 अगस्त 2019 Independence Day Celebrations</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/%e0%a4%87%e0%a4%82%e0%a4%a6%e0%a5%8c%e0%a4%b0-%e0%a4%9c%e0%a4%bf%e0%a4%b2%e0%a5%87-%e0%a4%ae%e0%a5%87%e0%a4%82-%e0%a4%a8%e0%a4%8f-%e0%a4%86%e0%a4%a7%e0%a4%be%e0%a4%b0-%e0%a4%aa%e0%a4%82%e0%a4%9c/">Advertisement for new Aadhar Enrollment/Updation Centers in Indore District from 03-08-2019 to 08-08-2019</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/gerr-vote-campaign-to-register-in-unesco-representative-heritage-list/">GERR : Vote Campaign to register in UNESCO Representative Heritage List</a>
                                                </li>
                        </ul>
                </div>
        
      </div></div><div class="vc_tta-panel" id="citizen-tab" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#citizen-tab" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">NOTIFICATION</span></a></h4></div><div class="vc_tta-panel-body"><div class="vc_wp_text wpb_content_element"><div class="widget widget_text"><h2 class="widgettitle">Registration Form: Job Fair for Differently Abled 2019</h2>			<div class="textwidget"><p>In relation to the rehabilitation of DivayangJan in Indore district, action is to be taken in the direction of providing employment / self employment to them on the basis of their educational qualification. Registration Process of DivyangJan Registration has been initiated for this activity. Registration form can be downloaded and completed Registration Form to be submitted in Office of Collector, Social Justice and Disability Welfare Department, Room No. G6, during Office Hours. Last date is 5th August 2019.</p>
<p><a href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/07/2019072226.pdf" target="_blank">Disabled people job seeker form English <span class="icon-pdf pdf-icon"></span> </a></p>
</div>
		</div></div></div></div><div class="vc_tta-panel" id="tender-tab" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#tender-tab" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">TENDER</span></a></h4></div><div class="vc_tta-panel-body">        <div class="gen-list  no-border no-bg  padding-0 border-radius-none default-list ">
                    <ul>
                            <li>
                                            <a href="https://indore.nic.in/en/notice/tender-notice-for-hiring-4-wheeler-diesel-vehicle-with-driver-in-duda-indore/">Tender Notice for Hiring 4 Wheeler Diesel Vehicle with Driver in DUDA Indore</a>
                                                </li>
                        </ul>
                </div>
        
      </div></div><div class="vc_tta-panel" id="1563865030306-e9ad01c9-589b" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#1563865030306-e9ad01c9-589b" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">NOTICE</span></a></h4></div><div class="vc_tta-panel-body">        <div class="gen-list  no-border no-bg  padding-0 border-radius-medium default-list ">
                    <ul>
                            <li>
                                            <a href="https://indore.nic.in/en/notice/section-144-order-no-1611-for-prevention-of-sound-pollution-in-indore/">Section 144 Order No. 1611 for prevention of Sound Pollution in Indore</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/notice/order-no-1625-u-s-144-prohibitory-order-regarding-use-of-vehicles-in-public-transport/">Order No 1625 u/s 144 : Prohibitory Order regarding Use of Vehicles in Public Transport</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/notice/district-indore-additional-collectors-work-distribution-order/">District Indore : Additional Collectors Work Distribution Order</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/notice/tender-notice-for-hiring-4-wheeler-diesel-vehicle-with-driver-in-duda-indore/">Tender Notice for Hiring 4 Wheeler Diesel Vehicle with Driver in DUDA Indore</a>
                                                </li>
                                <li>
                                            <a href="https://indore.nic.in/en/notice/order-no-83-u-s-144-regarding-giving-information-of-new-population-to-police-station-which-is-added-every-day-in-indore-city/">Order No 83 u/s 144 : Regarding giving Information to Police Station within maximum 15 days timelimit for New Population getting added to Indore City everyday</a>
                                                </li>
                        </ul>
                </div>
        
      </div></div></div></div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
    
    <div class="col-3 singlebox border ">
        
                <div class="box-1 ">
            <div class="khowMinisterBox">
                <div class="khowMinisterBoxImg">
                    <img class="" src="./projectibm_files/2019060797.jpg" alt="DM INDORE">
                </div>
                <div class="MinisterProfile">
                <span class="Pname">Collector </span>
                <span class="Pdesg">Lokesh Kumar Jatav</span>
                                                 <ul>
                                  
                                                  
                                  </ul>
                              </div>
            </div>
        </div>
                </div>

    </div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">	
		<div class="gen-list no-border no-bg padding-0 border-radius-none box-list   normal-font ">
		<h2 class="heading3">FIND SERVICES</h2>		<ul>
						<li class="blue-bg  border-radius-medium">
				<a  title="Certificates">
									<span class="list-icon icon-certificate border-radius-round"></span>
								<div class="list-text">Certificates				</div>
								</a>
				</li>
								<li class="green-bg  border-radius-medium">
				<a  title="Social Security">
									<span class="list-icon icon-social-3 border-radius-round"></span>
								<div class="list-text">Social Security				</div>
								</a>
				</li>
								<li class="red-bg  border-radius-medium">
				<a  title="Helpline">
									<span class="list-icon icon-supply border-radius-round"></span>
								<div class="list-text">Helpline				</div>
								</a>
				</li>
								<li class="orange-bg  border-radius-medium">
				<a  title="Revenue">
									<span class="list-icon icon-supply border-radius-round"></span>
								<div class="list-text">Revenue				</div>
								</a>
				</li>
								<li class="gray-bg  border-radius-medium">
				<a  title="Bills">
									<span class="list-icon icon-taxes-2 border-radius-round"></span>
								<div class="list-text">Bills				</div>
								</a>
				</li>
								<li class="light-grey-bg  border-radius-medium">
				<a  title="Hospital Online Service">
									<span class="list-icon icon-supply border-radius-round"></span>
								<div class="list-text">Hospital Online Service				</div>
								</a>
				</li>
						</ul>
				</div>
		</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">		<h2 class="heading3">PUBLIC UTILITIES</h2>		<div class="gen-list no-bg no-border normal-font  col-two padding-0 statistics-list ">
		<ul>
						
				<li>
				<a  title="Banks">
				<span class="list-icon border-radius-none blue-bg">9</span>
								<div class="list-text">Banks</div>
				</a>
				</li>
								
				<li>
				<a  title="Colleges/Universities">
				<span class="list-icon border-radius-none green-bg">11</span>
								<div class="list-text">Colleges/Universities</div>
				</a>
				</li>
								
				<li>
				<a  title="Electricity">
				<span class="list-icon border-radius-none red-bg">1</span>
								<div class="list-text">Electricity</div>
				</a>
				</li>
								
				<li>
				<a  title="Government Hospitals">
				<span class="list-icon border-radius-none orange-bg">3</span>
								<div class="list-text">Government Hospitals</div>
				</a>
				</li>
								
				<li>
				<a  title="Municipalities">
				<span class="list-icon border-radius-none gray-bg">1</span>
								<div class="list-text">Municipalities</div>
				</a>
				</li>
								
				<li>
				<a  title="Postal">
				<span class="list-icon border-radius-none light-grey-bg">5</span>
								<div class="list-text">Postal</div>
				</a>
				</li>
								
				<li>
				<a  title="Private Hospital">
				<span class="list-icon border-radius-none blue-bg">1</span>
								<div class="list-text">Private Hospital</div>
				</a>
				</li>
								
				<li>
				<a  title="Schools">
				<span class="list-icon border-radius-none green-bg">5</span>
								<div class="list-text">Schools</div>
				</a>
				</li>
						</ul>
				</div>
		</div></div></div></div><div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid vc_custom_1509962199792 vc_row-has-fill" style="position: relative; left: -117.4px; box-sizing: border-box; width: 1519px; padding-left: 117.4px; padding-right: 117.6px;"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_tta-container" data-vc-action="collapse"><div class="vc_general vc_tta vc_tta-tabs vc_tta-color-white vc_tta-style-classic vc_tta-shape-square vc_tta-spacing-1 home-slider-tab vc_tta-tabs-position-top vc_tta-controls-align-left home-slider-tab"><div class="vc_tta-tabs-container"><ul class="vc_tta-tabs-list" role="tablist"><li class="vc_tta-tab vc_active" data-vc-tab=""><a href="https://indore.nic.in/en/#photos-tab" data-vc-tabs="" data-vc-container=".vc_tta" role="tab" aria-controls="photos-tab" aria-selected="true"><i class="vc_tta-icon fa fa-picture-o"></i><span class="vc_tta-title-text">Photos</span></a></li></ul></div><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel vc_active" id="photos-tab" data-vc-content=".vc_tta-panel-body" role="tabpanel"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title"><a href="https://indore.nic.in/en/#photos-tab" data-vc-accordion="" data-vc-container=".vc_tta-container"><i class="vc_tta-icon fa fa-picture-o"></i><span class="vc_tta-title-text">Photos</span></a></h4></div><div class="vc_tta-panel-body">    <div class="carasoleflex-wrap dark-bg   ">
                 <div class="galleryMeta">
            
            
        </div>
        <div class="HomeGalleryCarasole flexslider">

                    <div class="flex-viewport" style="overflow: hidden; position: relative;"><ul class="slides" style="width: 600%; transition-duration: 0s; transform: translate3d(0px, 0px, 0px);">
                        
                                    <li class="fancyShare" style="width: 200px; float: left; display: block;">
                                    <div class="galleryThumb">
                                    
                                                                        <div class="hide fancySocial clearfix">
                                         <div class="socialBox">
                                           <ul>
                                             <li>
                                               </li>
                                               <li>
                                                
                                                 </li>
                                               </ul>
                                             </div>
                                           </div>
                                     </div>

                                </li>
                                
                                    <li class="fancyShare" style="width: 200px; float: left; display: block;">
                                    <div class="galleryThumb">
                                    <a  class="fancybox" title="Collector Office INDORE" rel="PhotoGallery">
                                     <img src="pro15.jpg" alt="collector office" draggable="false">
                                    </a>
                                                                        <div class="hide fancySocial clearfix">
                                         <div class="socialBox">
                                           <ul>
                                             <li><a href="https://www.facebook.com/sharer/sharer.php?u=https://indore.nic.in/en/&amp;t=RANGPANCHMI%20INDORE" onclick="javascript:window.open(this.href, &#39;&#39;, &#39;menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600&#39;);return false;" target="_blank" title="Share on Facebook" aria-label="Share on Facebook - External site that opens in a new window"><span class="icon-facebook"></span><span class="off-css">Share on Facebook</span></a>
                                               </li>
                                               <li>
                                                 <a href="https://twitter.com/share?url=https://indore.nic.in/en/&amp;via=TWITTER_HANDLE&amp;text=RANGPANCHMI%20INDORE" onclick="javascript:window.open(this.href, &#39;&#39;, &#39;menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600&#39;);return false;" target="_blank" title="Share on Twitter" aria-label="Share on Twitter - External site that opens in a new window"><span class="icon-twitter"></span><span class="off-css">Share on Twitter</span></a>
                                                 </li>
                                               </ul>
                                             </div>
                                           </div>
                                     </div>

                                </li>
                                
                                    <li class="fancyShare" style="width: 200px; float: left; display: block;">
                                    <div class="galleryThumb">
                                    <a  class="fancybox" title="district indore" rel="PhotoGallery">
                                     <img src="pro13.jpg" alt="Indore Culinary Delights" draggable="false">
                                    </a>
                                                                        <div class="hide fancySocial clearfix">
                                         <div class="socialBox">
                                           <ul>
                                             <li><a href="https://www.facebook.com/sharer/sharer.php?u=https://indore.nic.in/en/&amp;t=sarafa" onclick="javascript:window.open(this.href, &#39;&#39;, &#39;menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600&#39;);return false;" target="_blank" title="Share on Facebook" aria-label="Share on Facebook - External site that opens in a new window"><span class="icon-facebook"></span><span class="off-css">Share on Facebook</span></a>
                                               </li>
                                               <li>
                                                 <a href="https://twitter.com/share?url=https://indore.nic.in/en/&amp;via=TWITTER_HANDLE&amp;text=sarafa" onclick="javascript:window.open(this.href, &#39;&#39;, &#39;menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600&#39;);return false;" target="_blank" title="Share on Twitter" aria-label="Share on Twitter - External site that opens in a new window"><span class="icon-twitter"></span><span class="off-css">Share on Twitter</span></a>
                                                 </li>
                                               </ul>
                                             </div>
                                           </div>
                                     </div>

                                </li>
                                                    </ul></div><ul><li><a href="https://indore.nic.in/en/#" tabindex="-1" title="Previous" aria-label="Previous"><span class="hide">Previous</span></a></li><li><a  href="https://indore.nic.in/en/#" title="Next" aria-label="Next"><span class="hide">Next</span></a></li></ul></div>
    </div>

   <script>
jQuery(document).ready(function(e) {
//=========================
//js for photo gallery component design 2
     if(jQuery('body').hasClass('mva7-thc-activetheme-district-theme-5')){
        var itemWidth = 271;
     }else {
         var itemWidth = 200;
     }
//     (jQuery('body').hasClass('mva7-thc-activetheme-district-theme-5'))?271:
 jQuery(".HomeGalleryCarasole").flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        itemWidth: itemWidth,
        nextText: "<span class='hide'>Next</span>",
        prevText: "<span class='hide'>Previous</span>",
 });
 jQuery("#HomeVideoCarasole").flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        itemWidth: 200,
        nextText: "<span class='hide'>Next</span>",
        prevText: "<span class='hide'>Previous</span>",
 });

});
   </script>
    </div></div></div></div></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
		<div class="gen-list no-border no-bg padding-20 border-radius-none default-list importantLinksWrapper col-two normal-font ">
			<ul>
						
						</ul>
				</div>
		
		<div class="gen-list no-border no-bg padding-20 border-radius-none default-list importantLinksWrapper col-two normal-font ">
		<h2 class="heading3"><span class="icon-phone-2"></span> HELPLINE NUMBERS</h2>		<ul>
						<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text">Child Helpline : 1098				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text">Women Helpline : 1091				</div>
							 </div>
			 				</li>
								<li class="  ">
								<div class="list-anchor">
								<span class="list-icon -bg  border-radius-round"></span>
								<div class="list-text">State Women Helpline Number : 1090				</div>
							 </div>
			 				</li>
						</ul>
				</div>
		</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding" style="position: relative; left: -117.4px; box-sizing: border-box; width: 1519px;"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1500617027978"><div class="wpb_wrapper">    <div id="footerScrollbarWrapper" class="footerlogocarousel withbg withborder">
        <div>
            <div id="footerScrollbar" class="flexslider">
                
            <div class="flex-viewport" style="overflow: hidden; position: relative;"><ul class="slides" aria-label="Important Sites" style="width: 1600%; transition-duration: 0s; transform: translate3d(0px, 0px, 0px);">
                                                <li style="width: 201px; float: left; display: block;">
                                                                     <img src="./projectibm_files/2017053014.png" alt="data.gov.in" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                     <img src="./projectibm_files/2017053094.png" alt="Incredible India Site" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                   <img src="./projectibm_files/2017053052.png" alt="make in India" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                   <img src="./projectibm_files/2017053017.png" alt="mygov" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                     <img src="./projectibm_files/2017053039.png" alt="PMNRF" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                   
                                        <img src="./projectibm_files/2017110781.png" alt="pmindia" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                  
                                        <img src="./projectibm_files/2017053023.png" alt="india.gov.in" draggable="false">                                    </a>
                                                                </li>
                                                        <li style="width: 200px; float: left; display: block;">
                                                                    
                                        <img src="./projectibm_files/2017072418.png" alt="digital-india" draggable="false">                                    </a>
                                                                </li>
                                            </ul></div><ul class="flex-direction-nav"><li><a class="flex-prev" href="https://indore.nic.in/en/#" title="Previous" aria-label="Previous"><span class="hide">Previous</span></a></li><li><a class="flex-next" href="https://indore.nic.in/en/#" title="Next" aria-label="Next"><span class="hide">Next</span></a></li></ul><div class="flex-pauseplay"><a class="flex-pause" href="javascript:void(0)" title="Play/Pause" aria-label="Play/Pause"><span class="hide">Pause</span></a></div></div>
        </div>
    </div>
    <script>
     jQuery(document).ready(function(){
        jQuery("#footerScrollbar").flexslider({
        animation: "slide",
        animationLoop: true,
        itemWidth: 201,
        minItems: 2,
		slideshow: 1,
		move: 1,
		controlNav: false,
		pausePlay: true,
        prevText: "<span class='hide'>Previous</span>",
        nextText: "<span class='hide'>Next</span>",
        pauseText: "<span class='hide'>Pause</span>",
        playText: "<span class='hide'>Play</span>",

    })
    });
    </script>
    </div></div></div></div><div class="vc_row-full-width vc_clearfix"></div>

</div>
                    <!-- end of the loop -->
          
              </div>
          </div>
  </div>
</div>

<footer id="footer" class="footer-home">
  <div class="container">
    
</ul></div>    
        <div> <center> <img src="./projectibm_files/S3WaaS.png" ></a> <img src="./projectibm_files/nicLogo.png" ><img src="./projectibm_files/digitalIndia.png" alt="Digital India opens a new window"></a> <!-- <a href="#" class="stqc-logo"><img src="/common_utility/images/STQC-approved.png"  alt="STQC"></a> --> </center></div> 
      </div>
    </div>
  </footer>
  <script>
  jQuery(document).ready(function($){
    jQuery('.vc_tta-tabs-list').attr('role','tablist');
    jQuery('.vc_tta-panel').attr('role','tabpanel');
    jQuery('.vc_tta-tab a').attr('role','tab');
    jQuery('[data-vc-tabs]').each(function(){
        var id = jQuery(this).attr('href');
        id = id.replace('#','');
        jQuery(this).attr('aria-controls',id);
        if(jQuery(this).parent().hasClass('vc_active'))
        {
            jQuery(this).attr('aria-selected',true)
        }else{
            jQuery(this).attr('aria-selected',false)
        }
    });
    jQuery('[data-vc-tabs]').click(function(){
        jQuery(this).parent().siblings().find('a').attr('aria-selected',false);
        jQuery(this).attr('aria-selected',true);
    });

      jQuery('body').on('targetExternalLinks',function(){

          var isExternal = function(url) {
              return !(location.href.replace("http://", "").replace("https://", "").split("/")[0] === url.replace("http://", "").replace("https://", "").split("/")[0]);
          }
          jQuery('a').each(function(){
              var href = jQuery(this).attr('href');
              if(typeof href == 'undefined' ){
                  jQuery(this).attr('href','javascript:void(0)');
                  href = '#';
              }

             if($(this).attr('hreflang') !== undefined){
                  if(jQuery(this).attr('aria-label') !== typeof undefined){
                      jQuery(this).attr('aria-label', jQuery(this).text()).attr('title',jQuery(this).text());
                  }
              }else if(isExternal(href)){

                  if(href!='javascript:void(0);'
                      && !href.match("/^\/[a-z0-9]+jQuery/i")
                      && href!='#'  && href!='/' && href!=''
                      && !href.startsWith("#")
                      && href.indexOf('.') !== -1
                      && !jQuery(this).hasClass('fancybox.iframe')
                      && !jQuery(this).hasClass('fancybox')
                  ){
                      if(href.indexOf('cdn.s3waas.gov.in') == -1) {
                          if(typeof jQuery(this).attr('onclick') === "undefined"){
                              jQuery(this).attr("onclick", "return confirm('You are being redirected to an external website. Please note that District Indore,Goverment Of Madhya Pradesh cannot be held responsible for external websites content & privacy policies.');");
                          }
                      }
                      if(typeof jQuery(this).attr('aria-label') === "undefined" || typeof jQuery(this).attr('title') === "undefined"){
                          var text = '';
                          if(jQuery(this).text().trim() !== ''){
                              text = jQuery(this).text().trim()+' - ';
                          }else {
                              text = jQuery(this).attr('href')+' - ';
                          }

                          if(href.indexOf('cdn.s3waas.gov.in') == -1){

                              if(typeof jQuery(this).attr('aria-label') === "undefined"){
                                  jQuery(this).attr('aria-label', text + 'External site that opens in a new window');
                              }
                              if(typeof jQuery(this).attr('title') === "undefined"){
                                  jQuery(this).attr('title', text + 'External site that opens in a new window');
                              }

                          }
                      }
                      jQuery(this).prop('target', '_blank');
                  }
              }
          });

      })
      jQuery('body').trigger('targetExternalLinks');

    jQuery('body iframe').each(function () {
        var attrSrc = $(this).attr('src');
        if(attrSrc.indexOf('map') > 0){
            $(this).attr('title','District Map');
        }
    });

      $('.flex-direction-nav a.flex-prev').attr({'title' : 'Previous','aria-label':'Previous'});
      $('.flex-pauseplay a.flex-pause').attr({'title' : 'Play/Pause','aria-label':'Play/Pause'});
      $('.flex-direction-nav a.flex-next').attr({'title' : 'Next','aria-label':'Next'});

      $('a[download]').each(function(){

          var ariaLabel = $(this).prev().attr('aria-label').split('-')[0];
          ariaLabel = 'Download ' + ariaLabel;
          $(this).attr('aria-label',ariaLabel).removeAttr('aria-hidden');

      });
});

  </script>
  <link rel="stylesheet" id="flexslider-css" href="./projectibm_files/flexslider.min.css" media="all">
<link rel="stylesheet" id="custom-flexslider-css" href="./projectibm_files/custom-flexslider.css" media="all">
<link rel="stylesheet" id="list-style-css" href="./projectibm_files/list-style.min.css" media="all">
<link rel="stylesheet" id="component-helper-css" href="./projectibm_files/component-helper.css" media="all">
<link rel="stylesheet" id="events-css-css" href="./projectibm_files/events.css" media="all">
<link rel="stylesheet" id="vc_tta_style-css" href="./projectibm_files/js_composer_tta.min.css" media="all">
<link rel="stylesheet" id="min-profile-css" href="./projectibm_files/profile-hm.css" media="all">
<link rel="stylesheet" id="services-style-css" href="./projectibm_files/list-style.min.css" media="all">
<link rel="stylesheet" id="services-tabs-style-css" href="./projectibm_files/service-tabs.css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="./projectibm_files/font-awesome.min.css" media="all">
<link rel="stylesheet" id="home-gallery-css" href="./projectibm_files/photo-gallery-home.css" media="all">
<link rel="stylesheet" id="footer-style-css" href="./projectibm_files/footer-logo-carousel.css" media="all">
<script>
/* <![CDATA[ */
var AwaasData = {"ajaxUrl":"https:\/\/indore.nic.in\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script src="./projectibm_files/common.js(1).download"></script>
<script src="./projectibm_files/core.min.js.download"></script>
<script src="./projectibm_files/jquery.flexslider.js.download"></script>
<script src="./projectibm_files/easyResponsiveTabs.js.download"></script>
<script src="./projectibm_files/jquery.fancybox.js.download"></script>
<script src="./projectibm_files/style.switcher.js.download"></script>
<script src="./projectibm_files/table.min.js.download"></script>
<script src="./projectibm_files/custom.js.download"></script>
<script src="./projectibm_files/extra.js.download"></script>
<script src="./projectibm_files/menu.js.download"></script>
<script src="./projectibm_files/wp-embed.min.js.download"></script>
<script src="./projectibm_files/js_composer_front.min.js.download"></script>
<script src="./projectibm_files/jquery.flexslider-min.js.download"></script>
<script src="./projectibm_files/vc-accordion.min.js.download"></script>
<script src="./projectibm_files/vc-tta-autoplay.min.js.download"></script>
<script src="./projectibm_files/vc-tabs.min.js.download"></script>



<!-- Dynamic page generated in 0.729 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2019-09-07 10:26:51 -->

<!-- super cache --></body></html>