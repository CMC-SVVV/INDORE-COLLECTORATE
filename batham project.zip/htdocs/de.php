<?php

$link=mysqli_connect('localhost','root','','collectorate');	
$a=$_GET['sno'];
//echo $a;
$q="delete from collectrorate1 where sno='$a'";
$q1=mysqli_query($link,$q);
header("location:khushi.php");
?>
