
<?php

$link=mysqli_connect('localhost','root','','collectorate');	
	$a=$_GET['pn'];
	
	$q="select * from collectrorate1 where pn='$a'";
	$q1=mysqli_query($link,$q);

	if($a=mysqli_fetch_array($q1))
	{
	?>
	<form action="#" method="post">
		
		<h1 align=center>UPDATE</h1>
		<center>
		<table>
		<tr>	
<td>
	FIRST NAME<td><?php echo"<input type='text' name='FN' value='$a[1]'>"; ?><br>
		</tr><tr>
		MIDDLE NAME<td><?php echo"<input type='text' name='MN' value='$a[2]'>"; ?><br>
		</tr><tr>
	    LAST NAME<td><?php echo"<input type='text' name='LN' value='$a[3]'>"; ?><br>
		</tr><tr>
		<td>PHONE NUMBER<td><?php echo"<input type='text' name='pn' value='$a[4]'>";?><br>
		</tr><tr>
		<td>ADDRESS<td><?php echo"<input type='text' name='add' value='$a[5]'>";?><br>
		</tr><tr>
		<td>E-MAIL<td><?php echo"<input type='text' name='EM' value='$a[6]'>";?><br>
		</tr><tr>
		<td>PASSWORD<td><?php echo"<input type='password' name='pwd' value='$a[7]'>";?><br>
		</tr><tr>
		
		<tr><td rowspan=2><input type="submit" name="s" value="update"></td></tr>
		</table>
		</center>
	</form>






<?php
}


?>


<?php

$a1=$_POST['FN'];
$a2=$_POST['MN'];
$a3=$_POST['LN'];
$a4=$_POST['pn'];
$a5=$_POST['add'];
$a6=$_POST['EM'];
$a7=$_POST['pwd'];
$sno=$_GET['sno'];
if(isset($_POST['s']))
{
echo "hello".$pn.$a1;
		$link=mysqli_connect('localhost','root','','collectorate');	
$a9=$_GET['pn'];
$q="update collectrorate1 set firstname='.$a1.',middlename='.$a2.',lastname='.$a3.',address='.$a5.',phonenumber='.$a4.',email='.$a6.' where pn='$pn'";
$h=mysqli_query($link,$q);
header("location:ibm registration popup.php");


}
?>
