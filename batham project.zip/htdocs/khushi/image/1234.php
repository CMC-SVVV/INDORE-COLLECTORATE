

<form action = "" method = "post"  enctype="multipart/form-data" bgcolor="red" >
<div style="background-color:lightblue"><div style="background-color:darkblue">
	<center><pre>
		<font style="castellar">
	<h1><font color="white"> UPLOAD DOCUMENTS</font></h1></div>
	<br>
	<center>
      <label><h2>Choose Image:</h2></label> <br>                <input type="file" name="image"/><br><br>
</pre> 

	  <input type = "submit" name="s" value = " UPLOAD IMAGE ">   <input type = "submit" name="s1" value = " SHOW IMAGES ">
</font>
				</center>
               </form></div>
<div>
<h3>
<ol type="1">
<li>Application Form</li>
<li>Aadhar Card, Voter Id, Driving License, Passport, PAN Card</li>
<li>Transfer Certificate</li>
<li>A report regarding caste Patwari / Sarpanch</li>
<li>Caste certificate before marriage, in case of Women</li>
<li>Income certificate</li>
<li>Residence Proof</li>
<li>Caste / religion report</li>
</ol>
</h3>
</div>

		   
<?php

$link=mysqli_connect('localhost','root','','collectorate');


if(isset($_POST['s']))
{
$file_name = $_FILES['image']['name'];         
$file_tmp=$_FILES['image']['tmp_name'];
$file_store="tourism/".$file_name;
move_uploaded_file($file_tmp, $file_store);
$q="insert into img values('', '$file_name')";
$res1=mysqli_query($link,$q);
}
if(isset($_POST['s1']))
{
	$q1="select * from img";
	$r=mysqli_query($link,$q1);
	while ($a=mysqli_fetch_array($r))
	 {
		$d=$a['Name'];
		
?><center><div><img src="tourism/<?php echo $d; ?>" length="1000" width="1000"><br>
	                  <h2> <font color="red"><u><label><?php echo $d; ?></label></u></font></h2>
	              
	                  <a href="delete.php?id=<?php echo $a['ID']?>"><input type="submit" name="delete" value="Delete"></a><br><br>
					  
	                  
	                 
  </center></div>
	<?php  }
} ?>