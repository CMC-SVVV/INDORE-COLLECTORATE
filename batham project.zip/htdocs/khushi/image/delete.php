 <?php 
	                  		$link=mysqli_connect('localhost','root','','collectorate');

	                  			$query = mysqli_query($link, "DELETE FROM `img` WHERE `id` = '".$_GET['id']."'") or die(mysqli_error($link));
	                  			if ($query) {
	                  				
	                  				echo "<script>alert('Success')</script>";
	                  				echo "<script>window.open('imageuploadform.php', '_SELF');</script>";
	                  			}else {
	                  				echo "<script>alert('fail')</script>";
	                  				echo "<script>window.open('imageuploadform.php', '_SELF');</script>";
	                  			}
	                  		
	                  ?>