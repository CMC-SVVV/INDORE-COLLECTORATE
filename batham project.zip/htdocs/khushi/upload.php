<!DOCTYPE html>
<!-- saved from url=(0039)https://indore.nic.in/en/photo-gallery/ -->
<html lang="en-US" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>
  | District Indore,Goverment Of Madhya Pradesh | India  </title>
            <link rel="icon" href="./upload_files/2019062152.jpg">
      <style>
    @font-face {
      font-family: 'icomoon';
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq");
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq#iefix") format("embedded-opentype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.ttf?y6palq") format("truetype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.woff?y6palq") format("woff"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.svg?y6palq#icomoon") format("svg");
      font-weight: normal;
      font-style: normal; }
  </style>
  <link rel="profile">
  <link rel="pingback" >
    <link rel="dns-prefetch" >
<meta name="keywords" content="Photo, Gallery, Photo Gallery">
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/indore.nic.in\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./upload_files/wp-emoji-release.min.js.download" defer=""></script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="theme-my-login-css" href="./upload_files/theme-my-login.css" media="all">
<link rel="stylesheet" id="wp-block-library-css" href="./upload_files/style.min.css" media="all">
<link rel="stylesheet" id="base-css-css" href="./upload_files/base.css" media="all">
<link rel="stylesheet" id="extra-feature-css-css" href="./upload_files/extra.features.css" media="all">
<link rel="stylesheet" id="contact-form-7-css" href="./upload_files/styles.css" media="all">
<link rel="stylesheet" id="wsl-widget-css" href="./upload_files/style.css" media="all">
<link rel="stylesheet" id="sliderhelper-css-css" href="./upload_files/sliderhelper.css" media="all">
<link rel="stylesheet" id="main-css-css" href="./upload_files/style(1).css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="./upload_files/font-awsome.css" media="all">
<link rel="stylesheet" id="extra_css-css" href="./upload_files/extra.css" media="screen">
<script src="./upload_files/jquery.js.download"></script>
<script src="./upload_files/jquery-migrate.min.js.download"></script>
<script src="./upload_files/themed-profiles.js.download"></script>
<script src="./upload_files/external.js.download"></script>
<link rel="https://api.w.org/" href="https://indore.nic.in/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://indore.nic.in/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://indore.nic.in/wp-includes/wlwmanifest.xml"> 
<link rel="canonical" href="https://indore.nic.in/en/photo-gallery/">
<link rel="shortlink" href="https://indore.nic.in/?p=1547">
<link rel="alternate" type="application/json+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2Fphoto-gallery%2F">
<link rel="alternate" type="text/xml+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2Fphoto-gallery%2F&amp;format=xml">
    <noscript>
        <style>

            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ visibility: visible;}
            #topBar #accessibility ul li .socialIcons ul, #topBar1 #accessibility ul li .socialIcons ul { background: #fff !important;}
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ right: 0; left: inherit;}
            .nav li a:focus > ul { left: 0; opacity: 0.99;}
            a:focus, button:focus, .carasoleflex-wrap .flexslider .slides > li a:focus, .flexslider .slides>li a:focus
            { outline: 3px solid #ff8c00 !important;}
            .flexslider .slides>li { display:block;}
            .nav li.active > a, .nav li > a:hover, .nav li > a:focus, .nav ul li a:hover,
            .mva7-thc-activetheme-district-theme-13 .nav li:hover > a, .mva7-thc-activetheme-district-theme-13 .nav li.active > a, .home-13 .nav li:hover > a, .home-13 .nav li.active > a{color:#ffffff;}
            .nav li:hover > a{ border-top:none; color:#ffffff;}
            .nav li.active > a{ border:0;}
            .nav ul{ opacity:1; left:0; position:static !important; width:auto; border:0;}
            .nav li{ position:static !important; display:block; float:none; border:0 !important;}
            .nav li>a { float:none; display:block; background-color:rgba(146,38,4,0.75) !important; color:#ffffff; margin:0; padding:12px 20px !important; border-radius:0; border-bottom:1px solid #ffffff !important; position:static !important; border-top:0; font-size:14px !important;}
            .nav ul.sub-menu li >a{ background-color:rgba(146,38,4,1); font-size:12px !important;}
            ul li .socialIcons{ visibility:visible !important;}
            .mva7-thc-activetheme-district-theme .nav li > a,
            .mva7-thc-activetheme-district-theme .nav li.active > a{ background-color:#9e6b22 !important;}
            .mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a{ background-color:#f3b45b !important;}

            .mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .mva7-thc-activetheme-district-theme-15 .menuWrapper{ background-color:#ffffff;}

            .mva7-thc-activetheme-district-theme-2 .nav li > a,
            .mva7-thc-activetheme-district-theme-2 .nav li.active > a{ background-color:rgba(63,77,184,0.75) !important;}
            .mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a{ background-color:rgba(63,77,184,1) !important;}

            .mva7-thc-activetheme-district-theme-3 .nav li > a,
            .mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .mva7-thc-activetheme-district-theme-5 .nav li > a,
            .mva7-thc-activetheme-district-theme-5 .nav li.active > a{ background-color:rgba(212,60,60,0.75) !important;}
            .mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a{ background-color:rgba(212,60,60,1) !important;}

            .mva7-thc-activetheme-district-theme-4 .nav li > a,
            .mva7-thc-activetheme-district-theme-4 .nav li.active > a{ background-color:rgba(184,48,88,0.75) !important;}
            .mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a{ background-color:rgba(184,48,88,1) !important;}

            .mva7-thc-activetheme-district-theme-6 .nav li > a,
            .mva7-thc-activetheme-district-theme-6 .nav li.active > a{ background-color:rgba(16,91,122,0.75) !important;}
            .mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a{ background-color:rgba(16,91,122,1) !important;}

            .mva7-thc-activetheme-district-theme-7 .nav li > a,
            .mva7-thc-activetheme-district-theme-7 .nav li.active > a{ background-color:rgba(2,20,80,0.75) !important;}
            .mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a{ background-color:rgba(2,20,80,1) !important;}

            .mva7-thc-activetheme-district-theme-8 .nav li > a,
            .mva7-thc-activetheme-district-theme-8 .nav li.active > a{ background-color:rgba(0,144,145,0.65) !important;}
            .mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a{ background-color:rgba(0,144,145,1) !important;}

            .mva7-thc-activetheme-district-theme-9 .nav li > a,
            .mva7-thc-activetheme-district-theme-9 .nav li.active > a{ background-color:rgba(60,125,20,0.75) !important;}
            .mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a{ background-color:rgba(60,125,20,1) !important;}

            .mva7-thc-activetheme-district-theme-10 .nav li > a,
            .mva7-thc-activetheme-district-theme-10 .nav li.active > a{ background-color:rgba(233,13,65,0.70) !important;}
            .mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a{ background-color:rgba(233,13,65,1) !important;}

            .mva7-thc-activetheme-district-theme-11 .nav li > a,
            .mva7-thc-activetheme-district-theme-11 .nav li.active > a{ background-color:rgba(104,57,127,0.75) !important;}
            .mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a{ background-color:rgba(104,57,127,1) !important;}

            .mva7-thc-activetheme-district-theme-13 .nav li > a,
            .mva7-thc-activetheme-district-theme-13 .nav li.active > a{ background-color:rgba(0,0,0,0.75) !important;}
            .mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a{ background-color:rgba(0,0,0,1) !important;}

            .mva7-thc-activetheme-district-theme-14 .nav li > a,
            .mva7-thc-activetheme-district-theme-14 .nav li.active > a{ background-color:rgba(0,120,175,0.75) !important;}
            .mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a{ background-color:rgba(0,120,175,1) !important;}

            .mva7-thc-activetheme-district-theme-15 .nav li > a,
            .mva7-thc-activetheme-district-theme-15 .nav li.active > a{ background-color:rgba(150,86,104,0.75) !important;}
            .mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a{ background-color:rgba(150,86,104,1) !important;}y

            /*for high contrast css*/
            .contrast #topBar #accessibility ul li .socialIcons ul, .contrast #topBar1 #accessibility ul li .socialIcons ul,
            .contrast .nav li>a, .contrast .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-15 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a,
            body.contrast
            { background-color:#000 !important;}
            .contrast a, .contrast .socialIcons.select-lang a{ color:#ffff00 !important;}
            body.contrast, .contrast p, .contrast div, .contrast table{ color: #fff !important}
        </style>
    </noscript>
    <link rel="alternate" href="https://indore.nic.in/en/photo-gallery/" hreflang="x-default"><link rel="alternate" href="https://indore.nic.in/en/photo-gallery/" hreflang="en">
<link rel="alternate" href="https://indore.nic.in/%e0%a4%ab%e0%a5%8b%e0%a4%9f%e0%a5%8b-%e0%a4%97%e0%a5%88%e0%a4%b2%e0%a4%b0%e0%a5%80/" hreflang="hi">
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://indore.nic.in/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-32x32.jpg" sizes="32x32">
<link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-192x192.jpg" sizes="192x192">
<link rel="apple-touch-icon-precomposed" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-180x180.jpg">
<meta name="msapplication-TileImage" content="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-270x270.jpg">
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/html5shiv.min.js"></script>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/respond.min.js"></script>
<![endif]-->
<script>
  var ajaxurl = "https://indore.nic.in/wp-admin/admin-ajax.php";
</script>
<style type="text/css">.fancybox-margin{margin-right:17px;}</style></head>

<body class="page-template page-template-gallery page-template-gallery-php page page-id-1547 mva7-thc-activetheme-district-theme lang-en wpb-js-composer js-comp-ver-5.4.7 vc_responsive js" style="font-size: 14px;">
  <!--<header id="mainHeader">-->
    <header>
      <div id="topBar" class="wrapper">
        <div class="container">
          <div class="push-right" role="navigation" aria-label="Primary">
            <div id="accessibility">
            <ul id="accessibilityMenu">
                
                                               
                               
                <li>
                  <a href="javascript:void(0);" title="Accessibility Links" aria-label="Accessibility Links" class="mobile-show accessible-icon"><span class="off-css">Accessibility Links</span><span class="icon-accessibility" aria-hidden="true"></span></a>
                  <div class="accessiblelinks textSizing">
                    <ul>
                      <li><a href="javascript:void(0);" aria-label="Font Size Increase" title="Font Size Increase"><span aria-hidden="true">A+</span><span class="off-css"> Font Size Increase</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Normal Font" title="Normal Font"><span aria-hidden="true">A</span><span class="off-css"> Normal Font</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Font Size Decrease" title="Font Size Decrease"><span aria-hidden="true">A-</span><span class="off-css"> Font Size Decrease</span></a></li>
                      <li class="highContrast dark tog-con">
                          <a href="javascript:void(0);" aria-label="High Contrast" title="High Contrast"><span aria-hidden="true">A</span> <span class="tcon">High Contrast</span></a>
                      </li>
                      <li class="highContrast light">
                          <a href="javascript:void(0);" aria-hidden="true" aria-label="Normal Contrast" title="Normal Contrast"><span aria-hidden="true">A</span> <span class="tcon">Normal Contrast</span></a>
                      </li>
                    </ul>
                  </div>
                </li>
                                
                                                </ul>
                    </div>
                </li>
                              </ul>
            </div>
          </div>
          <div class="push-left">
            <div class="govBranding">
              <ul>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="wrapper header-wrapper">
        <div class="container header-container">
          <div class="logo">
            <a href="https://indore.nic.in/en/" aria-label="Go to home" class="emblem" rel="home">
                              <img class="site_logo" height="100" id="logo" src="./upload_files/2019062152.jpg" alt="MP Logo">
              
            <div class="logo-text">
                              <strong lang="hi" class="site_name_regional">जिला इंदौर </strong>
                                                              <span class="site_name_english">District Indore</span>
                                          </div>
          </a>
        </div>
          
          <div class="header-right clearfix">
            <div class="right-content clearfix">
              <div class="float-element">
                                                      
                      <img class="sw-logo" height="95" src="./upload_files/digital-india.png" alt="Digital India">
                    </a>
                                </div>
            </div>
          </div>
          <a class="menuToggle" href="javascript:void(0);" aria-label="Mobile Menu"> <span class="icon-menu"></span><span class="tcon">Menu Toggle</span></a>
        </div>
      </div>



<div class="menuWrapper" style="max-height: 517px;">

  <div class="menuMoreText hide"></div>


  <div class="container">
    <nav class="menu"><ul id="menu-header-en" class="nav clearfix" role="menubar" aria-hidden="false">





<li id="menu-item-2833" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2833" role="menuitem"><a href="http://localhost/khushi/ibm%20registration%20popup.php">REGISTRATION</a></li>
<li id="menu-item-2466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2466 has-sub" role="menuitem" aria-haspopup="true" aria-expanded="false"><a href="http://localhost/khushi/image/imageuploadform.php">CREATE <class="indicator1"></span></a>
<ul class="sub-menu" role="menu">
	
	
	
</ul>
</li>



  </div>
    
</div>
</header>
	<div class="wrapper banner-wrapper innerBanner">
    	  <img src="./upload_files/2019062938.jpg" alt="">
      	</div>
	
<section class="wrapper bodyWrapper" role="main">
  <div class="container">
   
	    	<div class="row breadcrumb-outer">

        	<div class="left-content push-left">
            	<div id="breadcam" role="navigation" aria-label="breadcrumb">
                           </div>
            </div>
            <div class="right-content push-right">
          
        </div>

        </div>
        <div id="SkipContent" tabindex="-1"></div>
    <div class="row" id="row-content">
    <div class="col-12">
	<div class="row">
        <div class="col-8">
          <h1>UPLOAD DOCUMENTS</h1>
        </div>
        <div class="col-4 textRight">
          <div class="viewSwicther"> <span class="icon-list-view"></span></a> </div>
        </div>
		<div class="col-12">
											</div>

    </div>
        <div id="photoGallery5">
                <div class="photoGallery4Inner equal-height thumbs_view">
                	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
                				    <img src="adhar card.jpg" alt="Khajrana Indore">
                				

				
	
			
		</div>
		<div class="photoGallery4ItemsCaption"> ADHAR CARD</div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
                				    <img src="transfer.jpg" alt="Patal Pani indore">
        

				
				
			 
		</div>
		<div class="photoGallery4ItemsCaption"> TRANSFER CERTIFICATE </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
		</div>
		<div class="photoGallery4ItemsCaption"> A report regarding caste Patwari / Sarpanch </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
                				    <img src="income1.jpg" alt="Choral Dam Mhow">
                				
		</div>
		<div class="photoGallery4ItemsCaption"> Income certificate  </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
                				    <img src="resi1.jpg" alt="Annapurna">
                
		</div>
		<div class="photoGallery4ItemsCaption"> Residence Proof  </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			<a href="https://indore.nic.in/en/gallery/anant-chaturdashi-chaudas/" title="View Gallery" aria-label="View Gallery">
                				    
		</div>
		<div class="photoGallery4ItemsCaption"> Caste / religion report  </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			
                				    <img src="application.jpg" alt="Indore Culinary Delights">
                				
		</div>
		<div class="photoGallery4ItemsCaption"> APPLICATION FORM </div>
	</div>	<div class="photoGallery4Items">
		<div class="photoGallery4ItemsImage"> 
			 
		</div>
		<div class="photoGallery4ItemsCaption"> Caste certificate before marriage, in case of Women</div>
	</div>
                </div>
              </div>
                     </div>
      </div>
   </div>
</section>

<footer id="footer">
  <div class="container">
      <div class="copyRights">
     
     
        <div class="copyRightsLogos"> <a ><img src="./upload_files/S3WaaS.png" alt="Secure, Scalable and Sugamya Website as a Service opens a new window"></a> <a ><img src="./upload_files/nicLogo.png" alt="National Informatics Centre opens a new window"></a> <a ><img src="./upload_files/digitalIndia.png" alt="Digital India opens a new window"></a> <!-- <a href="#" class="stqc-logo"><img src="/common_utility/images/STQC-approved.png"  alt="STQC"></a> --> </div>
      </div>
    </div>
  </footer>
  <script>
if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(searchString, position) {
    position = position || 0;
    return this.indexOf(searchString, position) === position;
  };
}
  jQuery(document).ready(function($){
    jQuery('.vc_tta-tabs-list').attr('role','tablist');
    jQuery('.vc_tta-panel').attr('role','tabpanel');
    jQuery('.vc_tta-tab a').attr('role','tab');
    jQuery('[data-vc-tabs]').each(function(){
        var id = jQuery(this).attr('href');
        id = id.replace('#','');
        jQuery(this).attr('aria-controls',id);
        if(jQuery(this).parent().hasClass('vc_active'))
        {
            jQuery(this).attr('aria-selected',true)
        }else{
            jQuery(this).attr('aria-selected',false)
        }
    });
    jQuery('[data-vc-tabs]').click(function(){
        jQuery(this).parent().siblings().find('a').attr('aria-selected',false);
        jQuery(this).attr('aria-selected',true);
    });

      jQuery('body').on('targetExternalLinks',function(){

          var isExternal = function(url) {
              return !(location.href.replace("http://", "").replace("https://", "").split("/")[0] === url.replace("http://", "").replace("https://", "").split("/")[0]);
          }
          jQuery('a').each(function(){
              var href = jQuery(this).attr('href');
              if(typeof href == 'undefined' ){
                  jQuery(this).attr('href','javascript:void(0)');
                  href = '#';
              }

             if($(this).attr('hreflang') !== undefined){
                  if(jQuery(this).attr('aria-label') !== typeof undefined){
                      jQuery(this).attr('aria-label', jQuery(this).text()).attr('title',jQuery(this).text());
                  }
              }else if(isExternal(href)){

                  if(href!='javascript:void(0);'
                      && !href.match("/^\/[a-z0-9]+jQuery/i")
                      &&  href!=''
                      && !href.startsWith("#")
                      && !href.startsWith("/")
                      && href.indexOf('.') !== -1
                      && !jQuery(this).hasClass('fancybox.iframe')
                      && !jQuery(this).hasClass('fancybox')
                  ){
                      if(href.indexOf('cdn.s3waas.gov.in') == -1 && href.indexOf('auth.s3waas.gov.in') == -1) {
                          if(typeof jQuery(this).attr('onclick') === "undefined"){
                              jQuery(this).attr("onclick", "return confirm('You are being redirected to an external website. Please note that District Indore,Goverment Of Madhya Pradesh cannot be held responsible for external websites content & privacy policies.');");
                          }
                      }
                      if(typeof jQuery(this).attr('aria-label') === "undefined" || typeof jQuery(this).attr('title') === "undefined"){
                          var text = '';
                          if(jQuery(this).text().trim() !== ''){
                              text = jQuery(this).text().trim()+' - ';
                          }else {
                              text = jQuery(this).attr('href')+' - ';
                          }

                          if(href.indexOf('cdn.s3waas.gov.in') == -1 && href.indexOf('auth.s3waas.gov.in') == -1){

                              if(typeof jQuery(this).attr('aria-label') === "undefined"){
                                  jQuery(this).attr('aria-label', text + 'External site that opens in a new window');
                              }
                              if(typeof jQuery(this).attr('title') === "undefined"){
                                  jQuery(this).attr('title', text + 'External site that opens in a new window');
                              }

                          }
                      }
                      if(href.indexOf('auth.s3waas.gov.in') == -1) {
                          jQuery(this).prop('target', '_blank');
                      }
                  }
              }
          });

      })
      jQuery('body').trigger('targetExternalLinks');

    jQuery('body iframe').each(function () {
        var attrSrc = $(this).attr('src');
        if(attrSrc.indexOf('map') > 0){
            $(this).attr('title','District Map');
        }
    });

      $('.flex-direction-nav a.flex-prev').attr({'title' : 'Previous','aria-label':'Previous'});
      $('.flex-pauseplay a.flex-pause').attr({'title' : 'Play/Pause','aria-label':'Play/Pause'});
      $('.flex-direction-nav a.flex-next').attr({'title' : 'Next','aria-label':'Next'});

      $('a[download]').each(function(){

          var ariaLabelPrevious = $(this).prev().attr('aria-label');
          if(typeof ariaLabelPrevious !== typeof undefined){
              var ariaLabel = $(this).prev().attr('aria-label').split('-')[0];
              ariaLabel = 'Download ' + ariaLabel;
              $(this).attr('aria-label',ariaLabel).removeAttr('aria-hidden');
          }
      });
});

  </script>
  <script>
/* <![CDATA[ */
var AwaasData = {"ajaxUrl":"https:\/\/indore.nic.in\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script src="./upload_files/common.js.download"></script>
<script src="./upload_files/core.min.js.download"></script>
<script src="./upload_files/jquery.flexslider.js.download"></script>
<script src="./upload_files/easyResponsiveTabs.js.download"></script>
<script src="./upload_files/jquery.fancybox.js.download"></script>
<script src="./upload_files/style.switcher.js.download"></script>
<script src="./upload_files/table.min.js.download"></script>
<script src="./upload_files/custom.js.download"></script>
<script src="./upload_files/extra.js.download"></script>
<script src="./upload_files/menu.js.download"></script>
<script src="./upload_files/wp-embed.min.js.download"></script>



<!-- Dynamic page generated in 87.281 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2019-10-08 16:38:10 -->

<!-- super cache --></body></html>