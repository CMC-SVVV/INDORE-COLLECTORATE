<?php


if(isset($_POST['s']))
  {
    $fn=$_POST['FN'];
  $mn=$_POST['MN'];
  $ln=$_POST['LN'];
  
  $add=$_POST['add'];
  $pn=$_POST['pn'];
  $em=$_POST['EM'];
  $pwd=$_POST['pwd'];
  
  
	echo $fn;
    $link=mysqli_connect('localhost','root','','collectorate');
    $qry="insert into collectrorate1 values('','$fn','$mn','$ln','$add','$pn','$em','$pwd')";
    mysqli_query($link,$qry);
	header("location:index.php"); 

  
	  
	   echo"<tr>";
	    echo"<td>";
		 echo $fn;
		  echo"</td>";
		   echo"<td>";
		    echo $mn;
			 echo"</td>";
			  echo"<td>";
			   echo $ln;
			    echo"</td>";
				 echo"<td>";
				  echo $add;
				   echo"</td>";
				    echo"<td>";
					 echo $pn;
					  echo"</td>"; 
					  echo"<td>";
					  echo $em;
					  echo"</td>";
					  echo"</tr>";
  }
  
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
    <title>Register form :: w3layouts</title>
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/style34.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" async="" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/analytics.js.download"></script><script async="" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/analytics.js.download"></script><script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--webfonts-->
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/css" '="" rel="stylesheet" type="text/css">
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/css(1)" rel="stylesheet" type="text/css">
    <!--webfonts-->
  <script id="_bsa_srv-CKYI653J_0" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYI653J.json"></script><script id="_bsa_srv-CKYI627U_1" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYI627U.json"></script><script id="_bsa_srv-CKYDL2JN_2" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYDL2JN.json"></script></head>
  <body style="">
<script src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/jquery.min.js.download"></script><script src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/monetization.js.download" type="text/javascript"></script>
</head>
<body>

<div class="container">
  <h2>Registration form</h2>
  <!-- Button to Open the Modal -->
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    CLICK HERE TO REGISTER 
  </button>

  <!-- The Modal -->
  <div class="modal fade " id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header ">
          <h4 class="modal-title" align="center">REGISTRATION FORM </h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  
    <title>Register form :: w3layouts</title>
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/style34.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" async="" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/analytics.js.download"></script><script async="" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/analytics.js.download"></script><script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--webfonts-->
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/css" '="" rel="stylesheet" type="text/css">
    <link href="./elegant login and Register forms Flat Widget Template __ w3layouts_files/css(1)" rel="stylesheet" type="text/css">
    <!--webfonts-->
  <script id="_bsa_srv-CKYI653J_0" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYI653J.json"></script><script id="_bsa_srv-CKYI627U_1" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYI627U.json"></script><script id="_bsa_srv-CKYDL2JN_2" type="text/javascript" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/CKYDL2JN.json"></script></head>
  <body style="">
<script src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/jquery.min.js.download"></script><script src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/monetization.js.download" type="text/javascript"></script>
<script>
(function(){
  if(typeof _bsa !== 'undefined' && _bsa) {
      // format, zoneKey, segment:value, options
      _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
    }
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
  // format, zoneKey, segment:value, options
  _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
  if(typeof _bsa !== 'undefined' && _bsa) {
      // format, zoneKey, segment:value, options
      _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
    }
})();
</script>
<!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/w3layouts_V2/vdo.ai.js?vdo=34");</script>-->
<div id="codefund"><div id="cf" style="font-family: Helvetica, Arial; font-size: 13px;"> <span class="cf-wrapper" style="box-sizing: border-box; position: fixed; bottom: 0; z-index: 5000; width: 100%; border-top-width: 1px; border-top-color: #bfbfbf; border-top-style: solid; background-color: #eeeeee; text-align: center; line-height: 1.5; padding: 0.8em 1em 1em;"> <a data-href="campaign_url" class="cf-text" target="_blank" rel="nofollow noopener" style="box-shadow: none !important; color: inherit; text-decoration: none;" href="https://codefund.io/impressions/bbeb2c6c-ef9f-49f3-8cc6-3a4656110430/click?campaign_id=450&amp;creative_id=425&amp;property_id=441&amp;template=bottom-bar&amp;theme=light"> <strong>Try Buildkite!</strong> <span>Fast, secure, and scalable CI/CD for all your software projects.</span> </a> <a href="https://codefund.io/invite/uaY8mStZDXQ" data-target="powered_by_url" class="cf-powered-by" target="_blank" rel="nofollow noopener" style="box-shadow: none !important; font-size: 12px; text-decoration: none; color: #999;"> <em>ethical</em> ad by CodeFund <img data-src="impression_url" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/pixel.gif"> </a> </span> </div> <style>#cf .cf-text:before { margin-right: 4px; padding: 2px 6px; border-radius: 3px; background-color: #4caf50; color: #fff; content: 'Supporter'; } #cf .cf-powered-by::before { content: ' '; color: rgba(0, 0, 0, 0.3); display: inline-block; } </style></div>
<script src="https://codefund.io/properties/441/funder.js" async="async"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="./elegant login and Register forms Flat Widget Template __ w3layouts_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<meta name="robots" content="noindex">
  
      <!--start-login-form-->
        <div class="main">
            <div class="login-head">
          <!---728x90--->

              <h1>Registration form</h1>
          </div>
          <div class="wrap">
              <div class="Regisration">
                <div class="Regisration-head">
                  <h2><span></span>Register</h2>
               </div>
                <form method="post">
              <input type="text" value="First Name" name="FN" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;First Name&#39;;}">
                  <input type="text" value="middle Name" name="MN" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;middle Name&#39;;}">
              
                  <input type="text" value="last Name" name="LN" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;last Name&#39;;}">
                  
                  <input type="text" value="address" name="add" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;address&#39;;}">
				  <input type="text" value="phone " name="pn" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;phone number_format&#39;;}">
                  <input type="text" value="Email" name="EM" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Email &#39;;}">
                <input type="password" value="Password" name="pwd"  onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Password&#39;;}">
                
                 <div class="Remember-me">
                
              </div>
                         
                <div class="submit">
                  <input type="submit" name="s" onclick="myFunction()" value="submit &gt;">
                </div>
                  <div class="clear"> </div>
                </div>
                      
              </form>
			  <table border="2">
			  <tr> 
			  
			  <td> FN </td>
			  <td> MN </td>
			  <td> LN </td>
			  <td> add </td>
			  <td> pn </td>
			  <td> EM </td>
			  </tr>
          <!---728x90--->

          

            
                      
              
          </div>
      </div>
      <!---728x90--->

        <!--//End-login-form--> 
            
  

  
        </div>
</table>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		  <button type="button" class="btn btn-danger" >update</button>
		  <button type="button" class="btn btn-danger" >delete</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div>

</body>
</html>

