<?php

		$link=mysqli_connect('localhost','root','','collectorate');
	$a=$_GET['phonenumber'];
	
	$q="select * from d1 where pn='$a[4]'";
	$q1=mysqli_query($link,$q);

	if($a[4]=mysqli_fetch_array($q1))
	{
	?>
	<form action="#" method="post">
		
		<h1 align=center> UPDATE </h1>
		<center>
		<table>
		<tr>	
<td>
	    FIRST NAME<td><?php echo"<input type='text' name='FN' value='$a[1]'>"; ?><br>
		</tr><tr>
		MIDDLE NAME<td><?php echo"<input type='text' name='MN' value='$a[2]'>"; ?><br>
		</tr><tr>
	    LAST NAME<td><?php echo"<input type='text' name='LN' value='$a[3]'>"; ?><br>
		</tr><tr>
		<td>PHONE NUMBER<td><?php echo"<input type='text' name='pn' value='$a[4]'>";?><br>
		</tr><tr>
		<td>ADDRESS<td><?php echo"<input type='text' name='add' value='$a[5]'>";?><br>
		</tr><tr>
		<td>E-MAIL<td><?php echo"<input type='text' name='EM' value='$a[6]'>";?><br>
		</tr><tr>
		<td>PASSWORD<td><?php echo"<input type='password' name='pwd' value='$a[7]'>";?><br>
		</tr><tr>
		
		<tr><td rowspan=2><input type="submit" name="s" value="update"></td></tr>
		</table>
		</center>
	</form>



<?php

$a1=$_POST['FN'];
$a2=$_POST['MN'];
$a3=$_POST['LN'];
$a4=$_POST['pn'];
$a5=$_POST['add'];
$a6=$_POST['EM'];
$a7=$_POST['pwd'];
$sno=$_GET['sno'];


if(isset($_POST['s']))
{
//echo "hello";
		$link=mysqli_connect('localhost','root','','collectorate');
$a9=$_GET['sno'];
$q="update d1 set fullname='.$a.',phone='.$a1.',address='.$a2.',hor='.$a3.',qualification='.$a4.',experience='.$a5.' where sno='$a9'";
$h=mysqli_query($link,$q);
header("location:ibm registration popup.php");


}

?>
<?php
}


?>
