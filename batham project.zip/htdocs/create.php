
<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>
  History | District Indore,Goverment Of Madhya Pradesh | India  </title>
            <link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019062152.jpg">
      <style>
    @font-face {
      font-family: 'icomoon';
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq");
      src: url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.eot?y6palq#iefix") format("embedded-opentype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.ttf?y6palq") format("truetype"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.woff?y6palq") format("woff"), url("https://indore.nic.in/wp-content/themes/district-theme/fonts/icomoon.svg?y6palq#icomoon") format("svg");
      font-weight: normal;
      font-style: normal; }
  </style>
  <link rel="profile" href="http://gmpg.org/xfn/11" />
  <link rel="pingback" href="https://indore.nic.in/xmlrpc.php" />
    <link rel='dns-prefetch' href='//s.w.org' />
<meta name="description" content="History of Indore The history of Indore reveals that the ancestors of the founders of the city were the hereditary Zamindars and indigenous landholders of Malwa. The families of these landlords led a luxurious life. They retained their possessions of royalty, including an elephant, Nishan, Danka and Gadi even after the advent of Holkars. They [&hellip;]" />
<meta name="keywords" content="History" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/indore.nic.in\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='theme-my-login-css'  href='https://indore.nic.in/wp-content/plugins/theme-my-login/theme-my-login.css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://indore.nic.in/wp-includes/css/dist/block-library/style.min.css' media='all' />
<link rel='stylesheet' id='base-css-css'  href='https://indore.nic.in/wp-content/themes/district-theme/css/base.css' media='all' />
<link rel='stylesheet' id='extra-feature-css-css'  href='https://indore.nic.in/wp-content/plugins/common_utility/css/extra.features.css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://indore.nic.in/wp-content/plugins/contact-form-7/includes/css/styles.css' media='all' />
<link rel='stylesheet' id='wsl-widget-css'  href='https://indore.nic.in/wp-content/plugins/wordpress-social-login/assets/css/style.css' media='all' />
<link rel='stylesheet' id='sliderhelper-css-css'  href='https://indore.nic.in/wp-content/themes/district-theme/css/sliderhelper.css' media='all' />
<link rel='stylesheet' id='main-css-css'  href='https://indore.nic.in/wp-content/themes/district-theme/style.css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://indore.nic.in/wp-content/plugins/awaas-accessibility/css/font-awsome.css' media='all' />
<link rel='stylesheet' id='extra_css-css'  href='https://indore.nic.in/wp-content/plugins/awaas-accessibility/css/extra.css' media='screen' />
<script src='https://indore.nic.in/wp-includes/js/jquery/jquery.js'></script>
<script src='https://indore.nic.in/wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script src='https://indore.nic.in/wp-content/plugins/theme-my-login/modules/themed-profiles/themed-profiles.js'></script>
<script src='https://indore.nic.in/wp-content/plugins/awaas-accessibility/js/external.js'></script>
<link rel='https://api.w.org/' href='https://indore.nic.in/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://indore.nic.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://indore.nic.in/wp-includes/wlwmanifest.xml" /> 
<link rel="canonical" href="https://indore.nic.in/en/history/" />
<link rel='shortlink' href='https://indore.nic.in/?p=2733' />
<link rel="alternate" type="application/json+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2Fhistory%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://indore.nic.in/wp-json/oembed/1.0/embed?url=https%3A%2F%2Findore.nic.in%2Fen%2Fhistory%2F&#038;format=xml" />
    <noscript>
        <style>
			
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ visibility: visible;}
            #topBar #accessibility ul li .socialIcons ul, #topBar1 #accessibility ul li .socialIcons ul { background: #fff !important;}
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ right: 0; left: inherit;}
            .nav li a:focus > ul { left: 0; opacity: 0.99;}
            a:focus, button:focus, .carasoleflex-wrap .flexslider .slides > li a:focus, .flexslider .slides>li a:focus
            { outline: 3px solid #ff8c00 !important;}
            .flexslider .slides>li { display:block;}
            .nav li.active > a, .nav li > a:hover, .nav li > a:focus, .nav ul li a:hover,
            .mva7-thc-activetheme-district-theme-13 .nav li:hover > a, .mva7-thc-activetheme-district-theme-13 .nav li.active > a, .home-13 .nav li:hover > a, .home-13 .nav li.active > a{color:#ffffff;}
            .nav li:hover > a{ border-top:none; color:#ffffff;}
            .nav li.active > a{ border:0;}
            .nav ul{ opacity:1; left:0; position:static !important; width:auto; border:0;}
            .nav li{ position:static !important; display:block; float:none; border:0 !important;}
            .nav li>a { float:none; display:block; background-color:rgba(146,38,4,0.75) !important; color:#ffffff; margin:0; padding:12px 20px !important; border-radius:0; border-bottom:1px solid #ffffff !important; position:static !important; border-top:0; font-size:14px !important;}
            .nav ul.sub-menu li >a{ background-color:rgba(146,38,4,1); font-size:12px !important;}
            ul li .socialIcons{ visibility:visible !important;}
            .mva7-thc-activetheme-district-theme .nav li > a,
            .mva7-thc-activetheme-district-theme .nav li.active > a{ background-color:#9e6b22 !important;}
            .mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a{ background-color:#f3b45b !important;}

            .mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .mva7-thc-activetheme-district-theme-15 .menuWrapper{ background-color:#ffffff;}

            .mva7-thc-activetheme-district-theme-2 .nav li > a,
            .mva7-thc-activetheme-district-theme-2 .nav li.active > a{ background-color:rgba(63,77,184,0.75) !important;}
            .mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a{ background-color:rgba(63,77,184,1) !important;}

            .mva7-thc-activetheme-district-theme-3 .nav li > a,
            .mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .mva7-thc-activetheme-district-theme-5 .nav li > a,
            .mva7-thc-activetheme-district-theme-5 .nav li.active > a{ background-color:rgba(212,60,60,0.75) !important;}
            .mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a{ background-color:rgba(212,60,60,1) !important;}

            .mva7-thc-activetheme-district-theme-4 .nav li > a,
            .mva7-thc-activetheme-district-theme-4 .nav li.active > a{ background-color:rgba(184,48,88,0.75) !important;}
            .mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a{ background-color:rgba(184,48,88,1) !important;}

            .mva7-thc-activetheme-district-theme-6 .nav li > a,
            .mva7-thc-activetheme-district-theme-6 .nav li.active > a{ background-color:rgba(16,91,122,0.75) !important;}
            .mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a{ background-color:rgba(16,91,122,1) !important;}

            .mva7-thc-activetheme-district-theme-7 .nav li > a,
            .mva7-thc-activetheme-district-theme-7 .nav li.active > a{ background-color:rgba(2,20,80,0.75) !important;}
            .mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a{ background-color:rgba(2,20,80,1) !important;}

            .mva7-thc-activetheme-district-theme-8 .nav li > a,
            .mva7-thc-activetheme-district-theme-8 .nav li.active > a{ background-color:rgba(0,144,145,0.65) !important;}
            .mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a{ background-color:rgba(0,144,145,1) !important;}

            .mva7-thc-activetheme-district-theme-9 .nav li > a,
            .mva7-thc-activetheme-district-theme-9 .nav li.active > a{ background-color:rgba(60,125,20,0.75) !important;}
            .mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a{ background-color:rgba(60,125,20,1) !important;}

            .mva7-thc-activetheme-district-theme-10 .nav li > a,
            .mva7-thc-activetheme-district-theme-10 .nav li.active > a{ background-color:rgba(233,13,65,0.70) !important;}
            .mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a{ background-color:rgba(233,13,65,1) !important;}

            .mva7-thc-activetheme-district-theme-11 .nav li > a,
            .mva7-thc-activetheme-district-theme-11 .nav li.active > a{ background-color:rgba(104,57,127,0.75) !important;}
            .mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a{ background-color:rgba(104,57,127,1) !important;}

            .mva7-thc-activetheme-district-theme-13 .nav li > a,
            .mva7-thc-activetheme-district-theme-13 .nav li.active > a{ background-color:rgba(0,0,0,0.75) !important;}
            .mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a{ background-color:rgba(0,0,0,1) !important;}

            .mva7-thc-activetheme-district-theme-14 .nav li > a,
            .mva7-thc-activetheme-district-theme-14 .nav li.active > a{ background-color:rgba(0,120,175,0.75) !important;}
            .mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a{ background-color:rgba(0,120,175,1) !important;}

            .mva7-thc-activetheme-district-theme-15 .nav li > a,
            .mva7-thc-activetheme-district-theme-15 .nav li.active > a{ background-color:rgba(150,86,104,0.75) !important;}
            .mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a{ background-color:rgba(150,86,104,1) !important;}y

            /*for high contrast css*/
            .contrast #topBar #accessibility ul li .socialIcons ul, .contrast #topBar1 #accessibility ul li .socialIcons ul,
            .contrast .nav li>a, .contrast .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-2 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-6 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-7 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-8 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-9 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-10 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-11 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-13 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-14 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-15 .menuWrapper,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-2 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-3 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-5 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-4 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-6 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-7 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-8 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-9 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-10 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-11 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-13 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-14 .nav ul.sub-menu li >a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav li.active > a,
            .contrast.mva7-thc-activetheme-district-theme-15 .nav ul.sub-menu li >a,
            body.contrast
            { background-color:#000 !important;}
            .contrast a, .contrast .socialIcons.select-lang a{ color:#ffff00 !important;}
            body.contrast, .contrast p, .contrast div, .contrast table{ color: #fff !important}
        </style>
    </noscript>
    <link rel="alternate" href="https://indore.nic.in/en/history/" hreflang="x-default"/><link rel="alternate" href="https://indore.nic.in/en/history/" hreflang="en" />
<link rel="alternate" href="https://indore.nic.in/%e0%a4%87%e0%a4%a4%e0%a4%bf%e0%a4%b9%e0%a4%be%e0%a4%b8/" hreflang="hi" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://indore.nic.in/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019082697-270x270.jpg" />
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/html5shiv.min.js"></script>
<script src="https://indore.nic.in/wp-content/themes/district-theme/js/respond.min.js"></script>
<![endif]-->
<script>
  var ajaxurl = "https://indore.nic.in/wp-admin/admin-ajax.php";
</script>
</head>

<body class="page-template-default page page-id-2733 mva7-thc-activetheme-district-theme lang-en wpb-js-composer js-comp-ver-5.4.7 vc_responsive">
  <!--<header id="mainHeader">-->
    <header>
      <div id="topBar" class="wrapper">
        <div class="container">
          <div class="push-right" role="navigation" aria-label="Primary">
            <div id="accessibility">
            <ul id="accessibilityMenu">
                <li><a href="#SkipContent" class="skip-to-content" title="Skip to main content"><span class="icon-skip-to-main responsive-show"></span><strong class="responsive-hide">SKIP TO MAIN CONTENT</strong></a></li>
                <li role="search"><a href="javascript:void(0);" title="Site Search"><span class="icon-search" aria-hidden="true"></span></a>
                  <div class="goiSearch">
                    <form onsubmit="return search_validation()" action="https://indore.nic.in/en/" method="get">
                        <label for="search" class="hide">Search</label>
                        <input type="text" title="Enter Text" name="s" id="search" value="" />
                        <button type="submit" title="Search"><small class="tcon">Search</small><span class="icon-search" aria-hidden="true"></span></button>
                    </form>
                    </div>
                </li>
                                <li role="complementary">
                  <a href="#" title="Social Media Links" class="show-social-links">
                    <span class="icon-social-link" aria-hidden="true">
                      <span class="icon-facebook"></span>
                      <span class="icon-twitter"></span>
                      <span class="icon-youtube"></span>
                    </span>
                    <span class="off-css">Social Media Links</span>
                  </a>
                  <div class="socialIcons">
                    <ul>

                  <li class="ico-social"><!--<a title="Social Media's" id="toggleSocial" href="javascript:void(0);"></a>-->
                    <ul>
                                              <li><a href="https://www.facebook.com/collectorindore" target="_blank" aria-label="Facebook | External site that opens in a new window"><img src="https://indore.nic.in/wp-content/themes/district-theme/images/ico-facebook.png" title="Facebook | External site that opens in a new window" alt="Facebook, External Link that opens in a new window"></a></li>
                                                                    <li><a href="https://twitter.com/Indorecollector" target="_blank" aria-label="Twitter | External site that opens in a new window"><img src="https://indore.nic.in/wp-content/themes/district-theme/images/ico-twitter.png" title="Twitter | External site that opens in a new window" alt="Twitter | External site that opens in a new window"></a></li>
                                                                </ul>
                  </li>
                    </ul>
                  </div>
                </li>
                                <li><a href="https://indore.nic.in/en/site-map/" title="Sitemap"><span class="off-css">Site Map</span><span class="icon-sitemap" aria-hidden="true"></span></a></li>
                <li>
                  <a href="javascript:void(0);" title="Accessibility Links" aria-label="Accessibility Links" class="mobile-show accessible-icon"><span class="off-css">Accessibility Links</span><span class="icon-accessibility" aria-hidden="true"></span></a>
                  <div class="accessiblelinks textSizing">
                    <ul>
                      <li><a href="javascript:void(0);" aria-label="Font Size Increase" title="Font Size Increase"><span aria-hidden="true">A+</span><span class="off-css"> Font Size Increase</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Normal Font" title="Normal Font"><span aria-hidden="true">A</span><span class="off-css"> Normal Font</span></a></li>
                      <li><a href="javascript:void(0);" aria-label="Font Size Decrease" title="Font Size Decrease"><span aria-hidden="true">A-</span><span class="off-css"> Font Size Decrease</span></a></li>
                      <li class="highContrast dark tog-con">
                          <a href="javascript:void(0);" aria-label="High Contrast" title="High Contrast"><span aria-hidden="true">A</span> <span class="tcon">High Contrast</span></a>
                      </li>
                      <li class="highContrast light">
                          <a href="javascript:void(0);" aria-hidden="true" aria-label="Normal Contrast" title="Normal Contrast"><span aria-hidden="true">A</span> <span class="tcon">Normal Contrast</span></a>
                      </li>
                    </ul>
                  </div>
                </li>
                                <li>
                  <a href="javascript:void(0);" class="change-language" aria-label="English" title="English">English</a>
                    <div class="socialIcons select-lang">
                      <ul>
                        	<li class="lang-item lang-item-2 lang-item-en lang-item-first current-lang"><a lang="en-US" hreflang="en-US" href="https://indore.nic.in/en/history/">English</a></li>
	<li class="lang-item lang-item-134 lang-item-hi"><a lang="hi-IN" hreflang="hi-IN" href="https://indore.nic.in/%e0%a4%87%e0%a4%a4%e0%a4%bf%e0%a4%b9%e0%a4%be%e0%a4%b8/">हिन्दी</a></li>
                      </ul>
                    </div>
                </li>
                              </ul>
            </div>
          </div>
          <div class="push-left">
            <div class="govBranding">
              <ul>
                <li><a lang="hi" href="http://www.mp.gov.in/web/guest/home" >मध्यप्रदेश शासन</a></li>
                <li><a href="http://www.mp.gov.in/en/web/guest/home">Government of Madhya Pradesh</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="wrapper header-wrapper">
        <div class="container header-container">
          <div class="logo">
            <a href="https://indore.nic.in/en/" aria-label="Go to home" class="emblem" rel="home">
                              <img class="site_logo" height="100" id="logo" src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019062152.jpg" alt="MP Logo" >
              
            <div class="logo-text">
                              <strong lang="hi" class="site_name_regional">जिला इंदौर </strong>
                                                              <span class="site_name_english">District Indore</span>
                                          </div>
          </a>
        </div>
          
          <div class="header-right clearfix">
            <div class="right-content clearfix">
              <div class="float-element">
                                                      <a aria-label="Digital India - External site that opens in a new window" href="http://digitalindia.gov.in/" target= "_blank" title="Digital India">
                      <img class="sw-logo" height="95" src="https://indore.nic.in/wp-content/themes/district-theme/images/digital-india.png" alt="Digital India">
                    </a>
                                </div>
            </div>
          </div>
          <a class="menuToggle" href="javascript:void(0);" aria-label="Mobile Menu"> <span class="icon-menu"></span><span class="tcon">Menu Toggle</span></a>
        </div>
      </div>



<div class="menuWrapper">

  <div class="menuMoreText hide">More</div>


  <div class="container">
    <nav class="menu"><ul id="menu-header-en" class="nav clearfix"><li id="menu-item-2658" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2658"><a href="/en">Home</a></li>
<li id="menu-item-2486" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-2486"><a href="https://indore.nic.in/en/about-district/">About District</a>
<ul class="sub-menu">
	<li id="menu-item-2736" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2733 current_page_item menu-item-2736 active "><a href="https://indore.nic.in/en/history/" aria-current="page">History</a></li>
	<li id="menu-item-2492" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2492"><a href="https://indore.nic.in/en/about-district/whos-who/">Who’s Who</a></li>
	<li id="menu-item-2739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2739"><a href="https://indore.nic.in/en/map-of-district/">Map of District</a></li>
	<li id="menu-item-2752" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2752"><a href="https://indore.nic.in/en/administrative-setup/">Administrative Setup</a>
	<ul class="sub-menu">
		<li id="menu-item-2755" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2755"><a href="https://indore.nic.in/en/collectorate/">Collectorate</a></li>
		<li id="menu-item-2758" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2758"><a href="https://indore.nic.in/en/tehsil/">Tehsil</a></li>
		<li id="menu-item-25311" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25311"><a href="https://indore.nic.in/en/tehsil-village/">Tehsil &#038; Village</a></li>
		<li id="menu-item-2774" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2774"><a href="https://indore.nic.in/en/subdivision-blocks/">Subdivision &#038; Blocks</a></li>
		<li id="menu-item-2772" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2772"><a href="https://indore.nic.in/en/police/">Police</a></li>
		<li id="menu-item-2770" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2770"><a href="https://indore.nic.in/en/constituency/">Constituency</a></li>
	</ul>
</li>
	<li id="menu-item-2751" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2751"><a href="https://indore.nic.in/en/demography/">Demography</a></li>
</ul>
</li>
<li id="menu-item-2777" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2777"><a href="https://indore.nic.in/en/directory/">Directory</a>
<ul class="sub-menu">
	<li id="menu-item-23567" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23567"><a href="https://indore.nic.in/en/dm-profiles/">DM PROFILE</a></li>
	<li id="menu-item-2787" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2787"><a href="https://indore.nic.in/en/std-pin-codes/">STD &#038; PIN Codes</a></li>
	<li id="menu-item-2788" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2788"><a href="https://indore.nic.in/en/helpline/">Helpline</a></li>
	<li id="menu-item-2786" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2786"><a href="https://indore.nic.in/en/public-utilities/">Public Utilities</a>
	<ul class="sub-menu">
		<li id="menu-item-17989" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17989"><a href="https://indore.nic.in/en/public-utility-category/banks/">Banks</a></li>
		<li id="menu-item-17990" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17990"><a href="https://indore.nic.in/en/public-utility-category/colleges/">Colleges/Universities</a></li>
		<li id="menu-item-17991" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17991"><a href="https://indore.nic.in/en/public-utility-category/electricity/">Electricity</a></li>
		<li id="menu-item-17992" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17992"><a href="https://indore.nic.in/en/public-utility-category/government-hospitals/">Government Hospitals</a></li>
		<li id="menu-item-25205" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-25205"><a href="https://indore.nic.in/en/public-utility-category/private-hospital/">Private Hospital</a></li>
		<li id="menu-item-17993" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17993"><a href="https://indore.nic.in/en/public-utility-category/municipality/">Municipalities</a></li>
		<li id="menu-item-17996" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17996"><a href="https://indore.nic.in/en/public-utility-category/postal/">Postal</a></li>
		<li id="menu-item-17997" class="menu-item menu-item-type-taxonomy menu-item-object-public-utility-category menu-item-17997"><a href="https://indore.nic.in/en/public-utility-category/schools/">Schools</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-2804" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2804"><a href="https://indore.nic.in/en/departments/">Departments</a>
<ul class="sub-menu">
	<li id="menu-item-26070" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26070"><a href="https://indore.nic.in/en/departments/revenue-department/">Revenue Department</a></li>
	<li id="menu-item-25999" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25999"><a href="https://indore.nic.in/en/district-election-office-indore/">District Election Office Indore</a></li>
	<li id="menu-item-24828" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24828"><a href="https://indore.nic.in/en/agriculture/">Agriculture</a></li>
	<li id="menu-item-24829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24829"><a href="https://indore.nic.in/en/horticulture/">Horticulture</a></li>
	<li id="menu-item-24854" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24854"><a href="https://indore.nic.in/en/animal-husbandry/">Animal Husbandry</a></li>
	<li id="menu-item-2803" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2803"><a href="https://indore.nic.in/en/health/">Health</a></li>
	<li id="menu-item-2802" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2802"><a href="https://indore.nic.in/en/education/">Education</a></li>
	<li id="menu-item-24636" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24636"><a href="https://indore.nic.in/en/social-security/">Social Justice &#038; Disability Welfare</a></li>
	<li id="menu-item-25539" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25539"><a href="https://indore.nic.in/en/departments/department-of-registration-and-stamps/">Department of Registration and Stamps</a></li>
</ul>
</li>
<li id="menu-item-2494" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2494"><a href="https://indore.nic.in/en/services/">Citizen Services</a></li>
<li id="menu-item-2829" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2829"><a href="https://indore.nic.in/en/tourism/">Tourism</a>
<ul class="sub-menu">
	<li id="menu-item-2828" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2828"><a href="https://indore.nic.in/en/how-to-reach/">How to Reach</a></li>
	<li id="menu-item-2827" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2827"><a href="https://indore.nic.in/en/places-of-interest/">Places of Interest</a></li>
	<li id="menu-item-24868" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24868"><a href="https://indore.nic.in/en/where-to-stay/">Accommodation (Hotel/Resort/Dharamsala)</a></li>
	<li id="menu-item-3364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3364"><a href="https://indore.nic.in/en/tourist-places/">Tourist Places</a></li>
	<li id="menu-item-23977" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23977"><a href="https://indore.nic.in/en/festivals/">Festivals</a></li>
	<li id="menu-item-23979" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23979"><a href="https://indore.nic.in/en/culinary-delights/">Culinary Delights</a></li>
	<li id="menu-item-23978" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23978"><a href="https://indore.nic.in/en/produce/">Produce</a></li>
</ul>
</li>
<li id="menu-item-3218" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3218"><a href="https://indore.nic.in/en/documents/">Documents</a>
<ul class="sub-menu">
	<li id="menu-item-2851" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-2851"><a href="https://indore.nic.in/en/document-category/office-order/">Office Order</a></li>
	<li id="menu-item-24680" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-24680"><a href="https://indore.nic.in/en/document-category/guidelines/">Guidelines</a></li>
	<li id="menu-item-2848" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-2848"><a href="https://indore.nic.in/en/document-category/district-profile/">District Profile</a></li>
</ul>
</li>
<li id="menu-item-2833" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2833"><a href="https://indore.nic.in/en/forms/">Forms</a></li>
<li id="menu-item-2466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2466"><a>Notices</a>
<ul class="sub-menu">
	<li id="menu-item-25963" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25963"><a href="https://indore.nic.in/en/notice_category/orders/">Orders</a></li>
	<li id="menu-item-26047" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-26047"><a href="https://indore.nic.in/en/notice_category/orders-under-section-144/">Orders under Section 144</a></li>
	<li id="menu-item-2493" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2493"><a href="https://indore.nic.in/en/events/">Events</a></li>
	<li id="menu-item-24674" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24674"><a href="https://indore.nic.in/en/upcoming-events/">Upcoming Events</a></li>
	<li id="menu-item-25739" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25739"><a href="https://indore.nic.in/en/notice_category/forms_registration_application/">REGISTRATION / APPLICATION FORMATS</a></li>
	<li id="menu-item-2467" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-2467"><a href="https://indore.nic.in/en/notice_category/tenders/">Tenders</a></li>
	<li id="menu-item-25735" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25735"><a href="https://indore.nic.in/en/notice_category/competitions/">Competitions</a></li>
	<li id="menu-item-25736" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25736"><a href="https://indore.nic.in/en/notice_category/press-release/">press-release</a></li>
	<li id="menu-item-25737" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25737"><a href="https://indore.nic.in/en/notice_category/announcements/">Announcements</a></li>
	<li id="menu-item-25738" class="menu-item menu-item-type-taxonomy menu-item-object-notice_category menu-item-25738"><a href="https://indore.nic.in/en/notice_category/recruitment/">Recruitment</a></li>
</ul>
</li>
<li id="menu-item-2495" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2495"><a href="https://indore.nic.in/en/schemes/">Schemes</a></li>
<li id="menu-item-2477" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2477"><a>Media Gallery</a>
<ul class="sub-menu">
	<li id="menu-item-2496" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2496"><a href="https://indore.nic.in/en/photo-gallery/">Photo Gallery</a></li>
	<li id="menu-item-25809" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-25809"><a href="https://indore.nic.in/en/category/press-release/">Press Release</a></li>
</ul>
</li>
<li id="menu-item-2837" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2837"><a href="https://indore.nic.in/en/rti/">RTI</a></li>
</ul></nav>
  </div>
</div>
<div class="clearfix"></div>
<div id="overflowMenu">
  <div class="ofMenu">
    <ul>

    </ul>
  </div>
    <a title="Close" href="javascript:void(0);" class="closeMenu"><span class="icon-close" aria-hidden="true"></span> Close</a>
</div>
</header>
	<div class="wrapper banner-wrapper innerBanner">
    	  <img src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019062938.jpg" alt="">
      	</div>
	
<div class="wrapper bodyWrapper " role="main">
    <div class="container ">
    
	    	<div class="row breadcrumb-outer">

        	<div class="left-content push-left">
            	<div id="breadcam" role="navigation" aria-label="breadcrumb">
                	<ul class="breadcrumbs"><li><a href="https://indore.nic.in/en/"  class="home"><span>Home</span></a></li><li><a href="https://indore.nic.in/en/about-district/">About District</a></li> <li class="current">History</li></ul><!-- .breadcrumbs -->                </div>
            </div>
            <div class="right-content push-right">
          <div class="printShare">
            <ul class="">
              <li><a href="#" id="print" title="Print" aria-label="Print Page Content"><span class="icon-printer"></span> <span class="off-css">Print</span></a></li>
              <li>
                                <span class="share-text"><em class="icon-share"></em><span class="off-css">Share</span></span>
						</li>
						<li>
                <a href="https://www.facebook.com/sharer/sharer.php?u=https://indore.nic.in/en/history/&t=History"
             onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
             target="_blank" title="Share on Facebook" aria-label="Facebook that opens in a new window"><span class="icon-facebook"></span><span class="off-css">Facebook</span></a>
					 </li>
					 <li>
								<a href="https://twitter.com/share?url=https://indore.nic.in/en/history/&via=TWITTER_HANDLE&text=History"
            onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
            target="_blank" title="Share on Twitter" aria-label="Twitter that opens in a new window"><span class="icon-twitter"></span><span class="off-css">Twitter</span></a>

              </li>
            </ul>
          </div>
        </div>

        </div>
        <div id="SkipContent"></div>
    <div class="row">
      <div class="col-12">
                  
            <h1>History</h1><div id="post-2733" class="post-2733 page type-page status-publish hentry">
		<div class="row">
<h2>History of Indore</h2>
<p>The history of Indore reveals that the ancestors of the founders of the city were the hereditary Zamindars and indigenous landholders of Malwa. The families of these landlords led a luxurious life. They retained their possessions of royalty, including an elephant, Nishan, Danka and Gadi even after the advent of Holkars. They even retained the right of performing the first pooja of Dussehra (Shami Pujan). During Mughal rule, the families were granted confirmatory sanads by the Emperors Aurangzeb, Alamgir and Farukhshayar, confirming their &#8216;Jagir&#8217; rights.</p>
<p>Indore, located on the Western region of Madhya Pradesh is one of the most important commercial centers of the state. The rich chronological history of Indore is worth considering. Even in days of yore it was an important business hub. But today with the entry of the corporate firms and institutions, it has earned a major name in the commercial sector of the country. As the story goes, Malharro Holkar of the Holkar clan, received Indore as part of his booty in the conquest of Malwa in 1733. His descendants, who formed the core part of Maratha confederacy, came into conflict with the Peshwas and Scindhias and continued the gory battle. There was a sharp turn in the History of Indore with the advent of the East India Company.<br />
The Holkars of Indore took part in the battle against the Britishers in 1803. Their glory was razed to dust when they were finally beaten in the Third Anglo Maratha war IN 1817- 1818.The Holkar dynasty had to admit defeat and give up a large portion of the territories under them. Matters came to an extreme when the English started intervening in their succession right. Two of the successors abdicated under mysterious circumstances. The History of Indore became murkier and dark as days went by till the independence of India when in 1947 the state came under the dominion of India.</p>
</div>
<div class="row">
<div class="pull-right sample-img-cntr"><img src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019061914.jpg" alt="RAJWADA" /></div>
<h2>R A J W A D A</h2>
<p>Rajwada is a historical palace in Indore city. It was built by the Holkars of the Maratha Empire about two centuries ago. This seven storied structure is located near the Chhatris and serves today as a fine example of royal grandeur and architectural skills.<br />
Also known as Holkar Palace, Rajawada is an important historical site in Indore that was constructed by the Holkars (belonging to the Maratha Dynasty) around 2 centuries ago. An example of the fine architectural skill and magnificence of those times, the palace is an impressive 7 storey structure that is placed near the Chhatris. One of the popular tourist attractions of Indore, Rajwada Palace is one of the oldest structures too. The palace was constructed by Malhar Rao Holkar, the founder of Holkar Dynasty in the year 1747 A.D. The palace was his residence and remained so till the year 1880 A.D. this remarkable structure is placed in Khajuri Bazaar, right in the middle of the city. Rajwada palace faces a well-maintained garden that has a statue of Queen Ahilya Bai, fountains and an artificial waterfall.</p>
</div>
<div class="row">
<h2>GANDHI HALL</h2>
<div class="pull-left sample-img-cntr"><img class="" src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019061997.jpg" alt="Gandhi Hall" width="309" height="203" /></div>
<p>King Edward Hall that was renamed as the Mahatma Gandhi Hall after the independence is one the most gorgeous buildings of Indore. Made in 1904 and originally named King Edwards Hall, it was renamed Mahatma Gandhi Hall in 1948. Its architectural style is Indo-Gothic. Made in Seoni stone, its domes and staples are a landmark of Indore today. It has a four-faced clock tower in front. It can accommodate 2,000 people at a time. It is one of the greatest landmarks of the city and is also frequently a venue for exhibitions and fairs throughout the year. The building also has a library, a children park and a temple.</p>
</div>
<div class="row">
<h2>LALBAGH PALACE</h2>
<div class="pull-right sample-img-cntr"><img src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019061962-1.jpg" alt="LALBAGH" /></div>
<p>Lal Baag Palace is one of the most spectacular buildings in Indore. It stands on the outskirts of the town, towards the southwest. It is a three storey building on the bank of the River Khan. The palace was built by Maharaja Shivaji Rao Holkar during 1886-1921.</p>
</div>
<div class="row">
<h2>CENTRAL MUSEUM</h2>
<div class="pull-left sample-img-cntr"><img src="https://cdn.s3waas.gov.in/s31385974ed5904a438616ff7bdb3f7439/uploads/2019/06/2019062072-e1561008701337.jpeg" alt="Central Museum" /></div>
<p>The Central Museum located at Indore displays some of the rare and elegant collection that deserves the status of being maintained, for the generations to see and learn from them. The main things that are on display at the museum are the Parmer Scriptures, different coins, armours and artifices. The history of the Central Museum at Indore dates back to the time of the Holka Dynasty when the Kings of the Holka Dynasty were persuaded to submit to the British, and so, a large part of the kingdom needed to be surrendered. This included their capital also, the present Cantonment.</p>
<p>The armors of the Holkas, their arms and ammunition have been kept with concern at the Museum in Indore. So, the Museum at Indore which is also known as the Central Museum has all the attractions that would make a classic collection, of choicest materials.</p>
</div>

</div>
                    <!-- end of the loop -->
          
              </div>
          </div>
  </div>
</div>

<footer id="footer" >
  <div class="container">
    <div class="footerMenu"><ul id="menu-footer-en" class="menu"><li id="menu-item-2501" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2501"><a href="https://indore.nic.in/en/website-policies/">Website Policies</a></li>
<li id="menu-item-2503" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2503"><a href="https://indore.nic.in/en/help/">Help</a></li>
<li id="menu-item-2506" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2506"><a href="https://indore.nic.in/en/contact-us/">Contact Us</a></li>
<li id="menu-item-2535" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2535"><a href="https://indore.nic.in/en/feedback/">Feedback</a></li>
</ul></div>    <div class="copyRights">
      <div class="pd-bottom5 color-white ctnt-ownd-dis">Content Owned by District Administration</div>
      <div class="copyRightsText">
                <p>© District Indore , Developed and hosted by <a href="http://www.nic.in/" target="_blank">National Informatics Centre</a>,<br><a href="http://meity.gov.in/" target="_blank">Ministry of Electronics & Information Technology</a>, Government of India</p>
					<p>Last Updated: <strong>Sep 07, 2019</strong></p>        </div>
        <div class="copyRightsLogos"> <a href="https://s3waas.gov.in/"><img src="https://indore.nic.in/wp-content/plugins/common_utility/images/S3WaaS.png"  alt="Secure, Scalable and Sugamya Website as a Service opens a new window"></a> <a href="http://www.nic.in/"><img src="https://indore.nic.in/wp-content/themes/district-theme/images/nicLogo.png"  alt="National Informatics Centre opens a new window"></a> <a href="http://www.digitalindia.gov.in/"><img src="https://indore.nic.in/wp-content/themes/district-theme/images/digitalIndia.png" alt="Digital India opens a new window"></a> <!-- <a href="#" class="stqc-logo"><img src="/common_utility/images/STQC-approved.png"  alt="STQC"></a> --> </div>
      </div>
    </div>
  </footer>
  <script>
  jQuery(document).ready(function($){
    jQuery('.vc_tta-tabs-list').attr('role','tablist');
    jQuery('.vc_tta-panel').attr('role','tabpanel');
    jQuery('.vc_tta-tab a').attr('role','tab');
    jQuery('[data-vc-tabs]').each(function(){
        var id = jQuery(this).attr('href');
        id = id.replace('#','');
        jQuery(this).attr('aria-controls',id);
        if(jQuery(this).parent().hasClass('vc_active'))
        {
            jQuery(this).attr('aria-selected',true)
        }else{
            jQuery(this).attr('aria-selected',false)
        }
    });
    jQuery('[data-vc-tabs]').click(function(){
        jQuery(this).parent().siblings().find('a').attr('aria-selected',false);
        jQuery(this).attr('aria-selected',true);
    });

      jQuery('body').on('targetExternalLinks',function(){

          var isExternal = function(url) {
              return !(location.href.replace("http://", "").replace("https://", "").split("/")[0] === url.replace("http://", "").replace("https://", "").split("/")[0]);
          }
          jQuery('a').each(function(){
              var href = jQuery(this).attr('href');
              if(typeof href == 'undefined' ){
                  jQuery(this).attr('href','javascript:void(0)');
                  href = '#';
              }

             if($(this).attr('hreflang') !== undefined){
                  if(jQuery(this).attr('aria-label') !== typeof undefined){
                      jQuery(this).attr('aria-label', jQuery(this).text()).attr('title',jQuery(this).text());
                  }
              }else if(isExternal(href)){

                  if(href!='javascript:void(0);'
                      && !href.match("/^\/[a-z0-9]+jQuery/i")
                      && href!='#'  && href!='/' && href!=''
                      && !href.startsWith("#")
                      && href.indexOf('.') !== -1
                      && !jQuery(this).hasClass('fancybox.iframe')
                      && !jQuery(this).hasClass('fancybox')
                  ){
                      if(href.indexOf('cdn.s3waas.gov.in') == -1) {
                          if(typeof jQuery(this).attr('onclick') === "undefined"){
                              jQuery(this).attr("onclick", "return confirm('You are being redirected to an external website. Please note that District Indore,Goverment Of Madhya Pradesh cannot be held responsible for external websites content & privacy policies.');");
                          }
                      }
                      if(typeof jQuery(this).attr('aria-label') === "undefined" || typeof jQuery(this).attr('title') === "undefined"){
                          var text = '';
                          if(jQuery(this).text().trim() !== ''){
                              text = jQuery(this).text().trim()+' - ';
                          }else {
                              text = jQuery(this).attr('href')+' - ';
                          }

                          if(href.indexOf('cdn.s3waas.gov.in') == -1){

                              if(typeof jQuery(this).attr('aria-label') === "undefined"){
                                  jQuery(this).attr('aria-label', text + 'External site that opens in a new window');
                              }
                              if(typeof jQuery(this).attr('title') === "undefined"){
                                  jQuery(this).attr('title', text + 'External site that opens in a new window');
                              }

                          }
                      }
                      jQuery(this).prop('target', '_blank');
                  }
              }
          });

      })
      jQuery('body').trigger('targetExternalLinks');

    jQuery('body iframe').each(function () {
        var attrSrc = $(this).attr('src');
        if(attrSrc.indexOf('map') > 0){
            $(this).attr('title','District Map');
        }
    });

      $('.flex-direction-nav a.flex-prev').attr({'title' : 'Previous','aria-label':'Previous'});
      $('.flex-pauseplay a.flex-pause').attr({'title' : 'Play/Pause','aria-label':'Play/Pause'});
      $('.flex-direction-nav a.flex-next').attr({'title' : 'Next','aria-label':'Next'});

      $('a[download]').each(function(){

          var ariaLabel = $(this).prev().attr('aria-label').split('-')[0];
          ariaLabel = 'Download ' + ariaLabel;
          $(this).attr('aria-label',ariaLabel).removeAttr('aria-hidden');

      });
});

  </script>
  <script type='text/javascript'>
/* <![CDATA[ */
var AwaasData = {"ajaxUrl":"https:\/\/indore.nic.in\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script src='https://indore.nic.in/wp-content/plugins/common_utility/js/common.js'></script>
<script src='https://indore.nic.in/wp-includes/js/jquery/ui/core.min.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/jquery.flexslider.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/easyResponsiveTabs.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/jquery.fancybox.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/style.switcher.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/table.min.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/custom.js'></script>
<script src='https://indore.nic.in/wp-content/themes/district-theme/js/extra.js'></script>
<script src='https://indore.nic.in/wp-content/plugins/awaas-accessibility/js/menu.js'></script>
<script src='https://indore.nic.in/wp-includes/js/wp-embed.min.js'></script>
</body>
</html>

<!-- Dynamic page generated in 0.382 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2019-09-07 21:40:02 -->

<!-- super cache -->